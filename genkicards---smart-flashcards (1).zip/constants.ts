
export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
export const GEMINI_IMAGE_MODEL = 'imagen-3.0-generate-002';

export const MOCK_API_KEY_WARNING = "API_KEY is not set. Using mock data and limited functionality. Please set your Google AI API key in environment variables (process.env.API_KEY) for full features.";

// Daily Review Limits
export const MAX_DAILY_REVIEW_LIMIT = 500;
export const MIN_DAILY_REVIEW_TARGET = 50; // Might be used for fetching new cards if due are less

// UltraMemo Algorithm Constants
export const INITIAL_STABILITY = 1; // S_initial: 1 day for new cards or after a lapse
export const MIN_STABILITY = 0.25; // Minimum stability (e.g., 6 hours)
export const MAX_STABILITY = 36500; // Max stability (e.g., 100 years)

export const INITIAL_DIFFICULTY_EASY = 0.2;
export const INITIAL_DIFFICULTY_MEDIUM = 0.5;
export const INITIAL_DIFFICULTY_HARD = 0.8;
export const MIN_DIFFICULTY = 0.05;
export const MAX_DIFFICULTY = 0.95;

export const T_MAX_RESPONSE_TIME_SECONDS = 30; // T_max for S and D calculations
export const A_MAX_CONSECUTIVE_CORRECT = 5; // A_max for D calculation (0-5 range)
export const USER_DIFFICULTY_WEIGHT_ALPHA = 0.3; // α: Peso da avaliação do usuário na dificuldade

// Mapping ReviewQuality to D_user for UltraMemo's difficulty update
export const D_USER_PERFECT = 0.2;         // For ReviewQuality.Perfect
export const D_USER_HESITATION = 0.4;    // For ReviewQuality.CorrectHesitation
export const D_USER_CORRECT_HARD = 0.6;  // For ReviewQuality.CorrectHard
export const D_USER_INCORRECT_EASY = 0.5; // For ReviewQuality.IncorrectEasy (felt easy but was wrong)
export const D_USER_INCORRECT_HARD = 0.8; // For ReviewQuality.IncorrectHard / ReviewQuality.Blackout

export const LEARNING_STABILITY_THRESHOLD_DAYS = 21; // Cards with stability < this are 'learning'
                                                // This replaces LEARNING_INTERVAL_THRESHOLD_DAYS
