
import { useState, useEffect, useCallback } from 'react';

// Fix: Add minimal polyfill interfaces for Web Speech API types
interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
  // Add other properties if used, e.g., emma, interpretation
}

interface SpeechRecognitionErrorEvent extends Event { // Changed from ErrorEvent to Event for broader compatibility if specific SpeechRecognitionErrorEvent props aren't used. Usually extends ErrorEvent
  readonly error: string; // Simplified, actual type is SpeechRecognitionErrorCode or DOMException
  readonly message: string;
}

interface SpeechGrammar {
  src: string;
  weight: number;
}
interface SpeechGrammarList {
  length: number;
  addFromString(string: string, weight?: number): void;
  addFromURI(src: string, weight?: number): void;
  item(index: number): SpeechGrammar;
  [index: number]: SpeechGrammar;
}
declare var SpeechGrammarList: {
  prototype: SpeechGrammarList;
  new(): SpeechGrammarList;
};


interface SpeechRecognition extends EventTarget {
  grammars: SpeechGrammarList;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onaudiostart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onaudioend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
  onnomatch: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onsoundstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onsoundend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onspeechstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onspeechend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  abort(): void;
  start(): void;
  stop(): void;
}

interface SpeechRecognitionStatic {
  new(): SpeechRecognition;
}


interface SpeechRecognitionHook {
  transcript: string;
  interimTranscript: string;
  isListening: boolean;
  startListening: () => void;
  stopListening: () => void;
  resetTranscript: () => void;
  error: string | null;
  browserSupportsSpeechRecognition: boolean;
}

// Extend the Window interface to include SpeechRecognition related properties
declare global {
  interface Window {
    // Fix: Use SpeechRecognitionStatic for constructor type
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

const useSpeechRecognition = (): SpeechRecognitionHook => {
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Fix: Use the defined SpeechRecognition interface for the instance type
  const [recognitionInstance, setRecognitionInstance] = useState<SpeechRecognition | null>(null);

  const browserSupportsSpeechRecognition = typeof window !== 'undefined' && 
    ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);

  useEffect(() => {
    if (!browserSupportsSpeechRecognition) {
      setError('Speech recognition not supported by this browser.');
      return;
    }

    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
        setError('Speech recognition API not found.');
        return;
    }
    const recognition: SpeechRecognition = new SpeechRecognitionAPI();
    
    recognition.continuous = true; // Keep listening even after a pause
    recognition.interimResults = true; // Get results while speaking
    recognition.lang = 'pt-BR'; // Default to Brazilian Portuguese, can be made configurable

    // Fix: Use the defined SpeechRecognitionEvent type
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscriptChunk = '';
      let interimTranscriptChunk = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscriptChunk += event.results[i][0].transcript;
        } else {
          interimTranscriptChunk += event.results[i][0].transcript;
        }
      }
      if (finalTranscriptChunk) {
        setTranscript(prev => prev + finalTranscriptChunk);
      }
      setInterimTranscript(interimTranscriptChunk);
    };

    // Fix: Use the defined SpeechRecognitionErrorEvent type
    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      let errorMessage = `Speech recognition error: ${event.error}`;
      if (event.error === 'network') {
        errorMessage = 'Network error during speech recognition. Please check your connection.';
      } else if (event.error === 'no-speech') {
        errorMessage = 'No speech detected. Please try speaking louder or closer to the microphone.';
      } else if (event.error === 'audio-capture') {
        errorMessage = 'Audio capture error. Is your microphone working and enabled?';
      } else if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        errorMessage = 'Microphone access denied. Please enable microphone permissions in your browser settings.';
      }
      setError(errorMessage);
      setIsListening(false); // Stop listening on error
    };
    
    recognition.onend = () => {
      // Only set isListening to false if it wasn't manually stopped or an error occurred
      // This allows continuous listening to resume if desired
      // If recognition.continuous is true, onend is called when stop() is called.
      // If continuous is false, it's called after a period of silence.
      // For this hook, we control listening state with start/stop explicitly.
    };

    setRecognitionInstance(recognition);

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [browserSupportsSpeechRecognition]);

  const startListening = useCallback(() => {
    if (recognitionInstance && !isListening) {
      try {
        setTranscript(''); // Clear previous final transcript
        setInterimTranscript(''); // Clear previous interim transcript
        setError(null);
        recognitionInstance.start();
        setIsListening(true);
      } catch (e) {
        // This catch is for errors during .start() itself, e.g., if already started
        console.error("Error starting speech recognition:", e);
        setError(`Error starting recognition: ${(e as Error).message}`);
        setIsListening(false);
      }
    }
  }, [recognitionInstance, isListening]);

  const stopListening = useCallback(() => {
    if (recognitionInstance && isListening) {
      recognitionInstance.stop();
      setIsListening(false);
    }
  }, [recognitionInstance, isListening]);
  
  const resetTranscript = useCallback(() => {
    setTranscript('');
    setInterimTranscript('');
  }, []);

  // Effect to append interim transcript to final when listening stops
  useEffect(() => {
    if (!isListening && interimTranscript) {
      setTranscript(prev => prev + interimTranscript);
      setInterimTranscript('');
    }
  }, [isListening, interimTranscript]);


  return { transcript, interimTranscript, isListening, startListening, stopListening, resetTranscript, error, browserSupportsSpeechRecognition };
};

export default useSpeechRecognition;
