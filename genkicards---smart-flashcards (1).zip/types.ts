
export interface Flashcard {
  id: string;
  pergunta: string;
  resposta: string;
  
  // UltraMemo Fields
  stability: number; // S: Tempo estimado (em dias) até o próximo esquecimento.
  difficulty: number; // D: Valor entre 0 (fácil) e 1 (difícil), ajustado por usuário e algoritmo.
  lastReviewedTimestamp?: number; // Unix timestamp (ms) of the last review. Needed for 't'.
  consecutiveCorrectAnswers: number; // A: Acertos consecutivos (0 a A_MAX).
  initialDifficultyEstimate?: 'fácil' | 'média' | 'difícil' | string; // Store original Gemini assessment
  lastResponseTimeSeconds?: number; // T for the last review for reference

  // Core Fields
  nextReviewDate: string; // ISO date string (calculada como lastReviewedDate + stability)
  lastReviewedDate?: string; // ISO date string
  tags?: string[];
  sourceType?: InputType;
  sourceInfo?: string;
  deckPath?: string;
  htmlContent?: boolean;

  // Dynamically calculated for UI, not stored unless for caching
  retrievability?: number; // R: Probabilidade de lembrar o card no momento atual (0 <= R <= 1).
  urgency?: number; // U: Prioridade de revisão.

  // Optional: Fields to help with quick state calculation in deckService
  dueToday?: boolean;
  status?: CardState;
}

export enum CardState {
  NEW = 'new', // Card has never been reviewed, or lastReviewedDate is undefined
  LEARNING = 'learning', // Card is due and stability < LEARNING_STABILITY_THRESHOLD
  REVIEW = 'review', // Card is due and stability >= LEARNING_STABILITY_THRESHOLD
  NOT_DUE = 'not_due', // Card's nextReviewDate is in the future
}


export enum ReviewQuality {
  Blackout = 0, // Erro total, não lembrava de nada.
  IncorrectHard = 1, // Errou, e a resposta pareceu difícil.
  IncorrectEasy = 2, // Errou, mas a resposta pareceu fácil quando vista.
  CorrectHard = 3, // Acertou, mas com dificuldade significativa.
  CorrectHesitation = 4, // Acertou, mas com alguma hesitação/incerteza.
  Perfect = 5, // Acertou, recordação perfeita e rápida.
}

export interface GeneratedFlashcardPayload {
  pergunta: string;
  resposta: string;
  dificuldade: 'fácil' | 'média' | 'difícil' | string; // Initial assessment from Gemini
  tags?: string[];
  deckPath?: string;
  htmlContent?: boolean;
}

export enum InputType {
  TEXT = 'text/link',
  IMAGE = 'image/pdf-page',
  VIDEO_TRANSCRIPT = 'video_transcript',
  VOICE_EXPLANATION = 'voice_explanation',
  MANUAL = 'manual_creation',
  ANKI_IMPORT = 'anki_import',
}

export enum AppView {
  HOME = 'HOME',
  CREATE_MANUAL = 'CREATE_MANUAL',
  CREATE_AUTOMATIC = 'CREATE_AUTOMATIC',
  VOICE_MODE = 'VOICE_MODE',
  REVIEW = 'REVIEW',
  SETTINGS = 'SETTINGS',
  DECK_DETAIL = 'DECK_DETAIL',
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  retrievedContext?: {
    uri: string;
    title: string;
  };
}

export interface GroundingMetadata {
  groundingAttributions?: {
    sourceId: {
      groundingAttributionSourceId?: {
        semanticRetrieverChunk?: {
          source: string;
          chunk: string;
        };
      };
    };
    content?: {
      web?: GroundingChunkWeb;
      retrievedContext?: {
        uri: string;
        title: string;
      };
    };
  }[];
  webSearchQueries?: string[];
  groundingChunks?: GroundingChunk[];
}

export interface ApiKeyCheckerProps {
  isApiKeySet: boolean;
}

export interface DeckStats {
  newCardsDue: number;
  learningCardsDue: number;
  reviewCardsDue: number;
  totalCardsInHierarchy: number;
  masteredCards: number; // Cards with stability >= LEARNING_STABILITY_THRESHOLD_DAYS
  progressPercent: number;
}

export interface DeckNodeData {
  name: string;
  fullPath: string;
  children: DeckNodeData[];
  stats: DeckStats;
}
