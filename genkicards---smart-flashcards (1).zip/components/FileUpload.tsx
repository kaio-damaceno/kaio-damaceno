
import React, { useState, useCallback } from 'react';
import { UploadCloud, X } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File, fileName: string) => void;
  disabled?: boolean;
  acceptedFileTypes?: string; // e.g., "image/png, image/jpeg"
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, disabled, acceptedFileTypes }) => {
  const [fileName, setFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSelect(file, file.name);
      setFileName(file.name);
    }
  }, [onFileSelect]);

  // Fix: Change React.DragEvent<HTMLDivElement> to React.DragEvent<HTMLLabelElement>
  const handleDrop = useCallback((event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    if (disabled) return;

    const file = event.dataTransfer.files?.[0];
    if (file) {
      if (acceptedFileTypes) {
        const typesArray = acceptedFileTypes.split(',').map(t => t.trim());
        if (!typesArray.includes(file.type)) {
          alert(`Invalid file type. Please upload one of: ${acceptedFileTypes}`);
          return;
        }
      }
      onFileSelect(file, file.name);
      setFileName(file.name);
    }
  }, [onFileSelect, disabled, acceptedFileTypes]);

  // Fix: Change React.DragEvent<HTMLDivElement> to React.DragEvent<HTMLLabelElement>
  const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (!disabled) setIsDragging(true);
  };

  // Fix: Change React.DragEvent<HTMLDivElement> to React.DragEvent<HTMLLabelElement>
  const handleDragLeave = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
  };
  
  const clearFile = () => {
    setFileName(null);
    // If you need to clear the input element itself:
    const input = document.getElementById('file-upload-input') as HTMLInputElement;
    if (input) input.value = '';
    // Note: onFileSelect(null, '') or similar might be needed if parent needs to know about clearing.
  };

  return (
    <div className="w-full">
      <label
        htmlFor="file-upload-input"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer transition-colors
                    ${disabled ? 'bg-slate-800 border-slate-700 cursor-not-allowed' : 
                    isDragging ? 'bg-sky-700 border-sky-500' : 
                    'bg-slate-700 hover:bg-slate-600 border-slate-500 hover:border-sky-500'}`}
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center">
          <UploadCloud className={`w-10 h-10 mb-3 ${disabled ? 'text-slate-500' : isDragging ? 'text-sky-300': 'text-slate-400'}`} />
          {fileName ? (
            <>
              <p className="mb-2 text-sm text-slate-300"><span className="font-semibold">{fileName}</span></p>
              <button 
                onClick={(e) => { e.preventDefault(); clearFile(); }} 
                className="text-xs text-red-400 hover:text-red-300 bg-red-900 hover:bg-red-800 px-2 py-1 rounded flex items-center"
                disabled={disabled}
              >
                <X size={14} className="mr-1" /> Clear
              </button>
            </>
          ) : (
            <>
              <p className={`mb-2 text-sm ${disabled ? 'text-slate-500' : 'text-slate-300'}`}>
                <span className="font-semibold">Click to upload</span> or drag and drop
              </p>
              <p className={`text-xs ${disabled ? 'text-slate-600' : 'text-slate-400'}`}>
                {acceptedFileTypes ? acceptedFileTypes.replace(/image\//g, '').toUpperCase() : 'Any file type'}
              </p>
            </>
          )}
        </div>
        <input 
          id="file-upload-input" 
          type="file" 
          className="hidden" 
          onChange={handleFileChange} 
          disabled={disabled}
          accept={acceptedFileTypes}
        />
      </label>
    </div>
  );
};

export default FileUpload;
