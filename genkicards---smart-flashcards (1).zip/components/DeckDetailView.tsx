
import React, { useState, useMemo } from 'react';
import { AppView, Flashcard, DeckNodeData, InputType } from '../types'; // Assuming DeckNodeData might be useful later
import { ArrowLeft, Edit3, Trash2, PlayCircle, Plus, Tag } from 'lucide-react';
import LoadingSpinner from './LoadingSpinner'; // If needed
import { marked } from 'marked';

interface DeckDetailViewProps {
  deckPath: string;
  allFlashcards: Flashcard[];
  onEditFlashcardRequest: (card: Flashcard) => void;
  onDeleteFlashcardRequest: (cardId: string) => void;
  setView: (view: AppView) => void;
  uniqueDeckPaths: string[]; // For potential "move card" functionality later
  handleStartReview: (deckPath: string | null) => void;
}

const DeckDetailView: React.FC<DeckDetailViewProps> = ({
  deckPath,
  allFlashcards,
  onEditFlashcardRequest,
  onDeleteFlashcardRequest,
  setView,
  uniqueDeckPaths,
  handleStartReview
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const cardsInThisDeck = useMemo(() => {
    return allFlashcards.filter(card => 
      (card.deckPath === deckPath || card.deckPath?.startsWith(deckPath + "::")) && 
      (card.pergunta.toLowerCase().includes(searchTerm.toLowerCase()) || 
       card.resposta.toLowerCase().includes(searchTerm.toLowerCase()) ||
       (card.tags && card.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))))
    ).sort((a,b) => a.pergunta.localeCompare(b.pergunta)); 
  }, [allFlashcards, deckPath, searchTerm]);

  const parentDeckPath = useMemo(() => {
    const segments = deckPath.split("::");
    if (segments.length > 1) {
      return segments.slice(0, -1).join("::");
    }
    return null; 
  }, [deckPath]);

  const renderCardPart = (content: string, isHtml: boolean | undefined) => {
    if (isHtml) {
      return <div dangerouslySetInnerHTML={{ __html: content }} />;
    }
    const markdownToHtml = marked.parse(content) as string;
    return <div className="markdown-content" dangerouslySetInnerHTML={{ __html: markdownToHtml }} />;
  };


  return (
    <div className="bg-slate-800 p-4 md:p-6 rounded-xl shadow-2xl animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => setView(AppView.HOME)}
          className="flex items-center text-sky-400 hover:text-sky-300 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          Voltar aos Baralhos
        </button>
        <button
            onClick={() => handleStartReview(deckPath)}
            className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center justify-center"
        >
            <PlayCircle size={18} className="mr-2"/> Estudar este Baralho
        </button>
      </div>

      <h2 className="text-2xl sm:text-3xl font-semibold mb-1 text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">
        Baralho: {deckPath.split("::").pop()}
      </h2>
      <p className="text-xs text-slate-400 mb-4 -mt-1">Caminho completo: {deckPath}</p>


      <input
        type="text"
        placeholder="Procurar cards neste baralho (pergunta, resposta ou tag)..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full p-3 mb-6 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none text-slate-100 placeholder-slate-400"
      />

      {cardsInThisDeck.length === 0 ? (
        <p className="text-slate-400 text-center py-6">
          {searchTerm ? "Nenhum card encontrado com este termo de busca." : "Este baralho está vazio ou não contém cards diretos (pode ter apenas sub-baralhos)."}
        </p>
      ) : (
        <div className="space-y-3 max-h-[calc(100vh-350px)] overflow-y-auto pr-2 custom-scrollbar">
          {cardsInThisDeck.map(card => (
            <div key={card.id} className="bg-slate-700/70 p-4 rounded-lg shadow-md hover:bg-slate-700 transition-colors group">
              <div className="flex justify-between items-start">
                <div className="flex-grow min-w-0"> 
                  <div className="font-semibold text-slate-100 break-words">{renderCardPart(card.pergunta, card.htmlContent)}</div>
                  <div className="text-sm text-slate-300 mt-1 break-words">{renderCardPart(card.resposta, card.htmlContent)}</div>
                   {card.deckPath !== deckPath && card.deckPath?.startsWith(deckPath + "::") && 
                     <p className="text-xs text-sky-400 mt-1">Sub-baralho: {card.deckPath}</p>
                   }
                   {card.tags && card.tags.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {card.tags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 bg-teal-600 text-teal-100 text-xs rounded-full flex items-center">
                          <Tag size={12} className="mr-1 opacity-80" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex-shrink-0 space-x-1 sm:space-x-2 ml-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEditFlashcardRequest(card)} title="Editar Card" className="p-1 sm:p-1.5 text-sky-400 hover:text-sky-300"><Edit3 size={16}/></button>
                  <button onClick={() => onDeleteFlashcardRequest(card.id)} title="Excluir Card" className="p-1 sm:p-1.5 text-red-400 hover:text-red-300"><Trash2 size={16}/></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
        <button
            onClick={() => {
                alert("Para adicionar um card diretamente a este baralho, use 'Criação Manual' na tela inicial e especifique este caminho de baralho ou um sub-caminho.");
                setView(AppView.CREATE_MANUAL); 
            }}
            className="mt-6 w-full sm:w-auto bg-teal-500 hover:bg-teal-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md flex items-center justify-center"
        >
           <Plus size={18} className="mr-2"/> Adicionar Card a este Baralho
        </button>
    </div>
  );
};

export default DeckDetailView;