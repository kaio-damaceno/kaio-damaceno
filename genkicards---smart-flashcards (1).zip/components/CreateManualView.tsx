
import React, { useState, useEffect } from 'react';
import { InputType, GeneratedFlashcardPayload } from '../types';
import { Save, CheckCircle, AlertTriangle, FolderTree, Code } from 'lucide-react';

interface CreateManualViewProps {
  addFlashcards: (cardsData: GeneratedFlashcardPayload[], sourceType: InputType, sourceInfo?: string) => void;
  setIsLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  existingDeckPaths: string[];
  initialDeckPath?: string | null; // Added prop for pre-filled deck path
  onInitialDeckPathConsumed?: () => void; // Added prop to clear initialDeckPath in App.tsx
}

const CreateManualView: React.FC<CreateManualViewProps> = ({ 
  addFlashcards, 
  setIsLoading, 
  setError, 
  existingDeckPaths,
  initialDeckPath,
  onInitialDeckPathConsumed
}) => {
  const [pergunta, setPergunta] = useState('');
  const [resposta, setResposta] = useState('');
  const [dificuldade, setDificuldade] = useState<'fácil' | 'média' | 'difícil'>('média');
  const [deckPath, setDeckPath] = useState('');
  const [htmlContent, setHtmlContent] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialDeckPath) {
      setDeckPath(initialDeckPath);
      if (onInitialDeckPathConsumed) {
        onInitialDeckPathConsumed();
      }
    } else {
        // Reset deckPath if initialDeckPath is not provided on subsequent renders (e.g. navigating back)
        // Or, only set if it's a fresh mount, depending on desired behavior.
        // For now, let's allow it to persist if user manually changes it after pre-fill.
    }
  }, [initialDeckPath, onInitialDeckPathConsumed]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!pergunta.trim() || !resposta.trim()) {
      setError("Question and Answer fields cannot be empty.");
      return;
    }

    setIsLoading(true);
    try {
      const newCard: GeneratedFlashcardPayload = {
        pergunta,
        resposta,
        dificuldade,
        deckPath: deckPath.trim() || 'Default',
        htmlContent: htmlContent,
      };
      addFlashcards([newCard], InputType.MANUAL, 'User Created');
      // Only reset if NOT coming from a "create new deck" flow
      // The App.tsx addFlashcards will navigate home if pendingDeckPathForManualCard was set
      if (!initialDeckPath) { // If it was pre-filled, App will navigate away.
          setPergunta('');
          setResposta('');
          setDificuldade('média');
          setDeckPath(''); // Reset deckPath for next manual creation not tied to new deck flow
          setHtmlContent(false);
      }
      setSuccessMessage('Flashcard added successfully! View it on the Home screen or continue adding.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      console.error("Error adding manual flashcard:", err);
      setError("Failed to add flashcard. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-6 md:p-8 rounded-xl shadow-2xl animate-fadeIn">
      <h2 className="text-3xl font-semibold mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-lime-300">
        Create Flashcard Manually
      </h2>

      {successMessage && (
        <div className="bg-green-500 border border-green-600 text-white px-4 py-3 rounded-lg relative mb-4 flex items-center" role="alert">
          <CheckCircle className="h-5 w-5 mr-2" />
          <span className="block sm:inline">{successMessage}</span>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="pergunta" className="block text-sm font-medium text-slate-300 mb-1">
            Question (Frente):
          </label>
          <textarea
            id="pergunta"
            value={pergunta}
            onChange={(e) => setPergunta(e.target.value)}
            rows={3}
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-slate-100 placeholder-slate-400"
            placeholder="e.g., What is the capital of France? Supports Markdown/HTML if checked below."
            required
          />
        </div>

        <div>
          <label htmlFor="resposta" className="block text-sm font-medium text-slate-300 mb-1">
            Answer (Verso):
          </label>
          <textarea
            id="resposta"
            value={resposta}
            onChange={(e) => setResposta(e.target.value)}
            rows={4}
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-slate-100 placeholder-slate-400"
            placeholder="e.g., Paris. Supports Markdown/HTML if checked below."
            required
          />
        </div>
        
        <div>
          <label htmlFor="deckPath-manual" className="block text-sm font-medium text-slate-300 mb-1">
            Deck Path (e.g., Subject::Topic or select existing):
          </label>
          <div className="relative">
            <FolderTree className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 pointer-events-none" />
            <input
              type="text"
              id="deckPath-manual"
              value={deckPath}
              onChange={(e) => setDeckPath(e.target.value)}
              list="existing-deck-paths"
              className="w-full p-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-slate-100 placeholder-slate-400"
              placeholder="Default (or type new path)"
            />
            <datalist id="existing-deck-paths">
              {existingDeckPaths.map(path => (
                <option key={path} value={path} />
              ))}
            </datalist>
          </div>
           <p className="text-xs text-slate-400 mt-1">Use '::' to separate parent/child decks (e.g., Science::Biology::Cells).</p>
        </div>

        <div>
          <label htmlFor="dificuldade" className="block text-sm font-medium text-slate-300 mb-1">
            Initial Difficulty:
          </label>
          <select
            id="dificuldade"
            value={dificuldade}
            onChange={(e) => setDificuldade(e.target.value as 'fácil' | 'média' | 'difícil')}
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-slate-100"
          >
            <option value="fácil">Fácil (Easy)</option>
            <option value="média">Média (Medium)</option>
            <option value="difícil">Difícil (Hard)</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
            <input
            id="htmlContent-manual"
            type="checkbox"
            checked={htmlContent}
            onChange={(e) => setHtmlContent(e.target.checked)}
            className="h-4 w-4 text-sky-600 border-slate-500 rounded focus:ring-sky-500"
            />
            <label htmlFor="htmlContent-manual" className="text-sm font-medium text-slate-300 flex items-center">
                <Code size={16} className="mr-1.5 text-sky-400"/> Conteúdo é HTML (desmarque para Markdown/texto simples)
            </label>
        </div>


        <button
          type="submit"
          className="w-full bg-gradient-to-r from-teal-500 to-lime-500 hover:from-teal-600 hover:to-lime-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-150 ease-in-out flex items-center justify-center text-lg disabled:opacity-50"
        >
          <Save className="mr-2" /> Add Flashcard
        </button>
      </form>
    </div>
  );
};

export default CreateManualView;
