
import React, { useState, useEffect } from 'react';
import { Flashcard } from '../types';
import { Save, XCircle, FolderTree, Code } from 'lucide-react';

interface EditFlashcardModalProps {
  flashcardToEdit: Flashcard;
  onSaveFlashcard: (updatedCard: Flashcard) => void;
  onCancel: () => void;
  uniqueDeckPaths: string[];
}

const EditFlashcardModal: React.FC<EditFlashcardModalProps> = ({ 
    flashcardToEdit, onSaveFlashcard, onCancel, uniqueDeckPaths 
}) => {
  const [pergunta, setPergunta] = useState(flashcardToEdit.pergunta);
  const [resposta, setResposta] = useState(flashcardToEdit.resposta);
  const [deckPath, setDeckPath] = useState(flashcardToEdit.deckPath || 'Default');
  // For UltraMemo, 'dificuldadeOriginal' is more like an initial estimate.
  // The true 'difficulty' (0-1) and 'stability' are managed by the algorithm.
  // We can allow editing the 'initialDifficultyEstimate' if desired.
  const [initialDifficultyEstimate, setInitialDifficultyEstimate] = useState(flashcardToEdit.initialDifficultyEstimate);
  const [tags, setTags] = useState((flashcardToEdit.tags || []).join(', '));
  const [htmlContent, setHtmlContent] = useState(flashcardToEdit.htmlContent || false);
  const [error, setError] = useState<string | null>(null);


  useEffect(() => {
    setPergunta(flashcardToEdit.pergunta);
    setResposta(flashcardToEdit.resposta);
    setDeckPath(flashcardToEdit.deckPath || 'Default');
    setInitialDifficultyEstimate(flashcardToEdit.initialDifficultyEstimate);
    setTags((flashcardToEdit.tags || []).join(', '));
    setHtmlContent(flashcardToEdit.htmlContent || false);
    setError(null);
  }, [flashcardToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pergunta.trim() || !resposta.trim()) {
      setError("Pergunta e Resposta não podem estar vazios.");
      return;
    }
    setError(null);
    
    const updatedCard: Flashcard = {
      ...flashcardToEdit,
      pergunta: pergunta.trim(),
      resposta: resposta.trim(),
      deckPath: deckPath.trim() || 'Default',
      initialDifficultyEstimate: initialDifficultyEstimate, // User can change the initial classification
      tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      htmlContent,
      // Note: Editing stability, difficulty, consecutiveCorrectAnswers directly is typically not done here.
      // Those are outcomes of reviews. If initialDifficultyEstimate changes,
      // the card's 'difficulty' might be reset/re-evaluated if it's a new card or based on app logic,
      // but this modal primarily handles content and categorization edits.
    };
    onSaveFlashcard(updatedCard);
  };

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-75 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div 
        className="bg-slate-800 p-6 rounded-lg shadow-xl w-full max-w-lg my-auto animate-fadeIn"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-sky-300">Editar Flashcard</h2>
          <button onClick={onCancel} className="text-slate-400 hover:text-slate-200">
            <XCircle size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="edit-pergunta" className="block text-sm font-medium text-slate-300 mb-1">
              Pergunta (Frente):
            </label>
            <textarea
              id="edit-pergunta"
              value={pergunta}
              onChange={(e) => setPergunta(e.target.value)}
              rows={3}
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500"
              required
            />
          </div>
          <div>
            <label htmlFor="edit-resposta" className="block text-sm font-medium text-slate-300 mb-1">
              Resposta (Verso):
            </label>
            <textarea
              id="edit-resposta"
              value={resposta}
              onChange={(e) => setResposta(e.target.value)}
              rows={4}
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500"
              required
            />
          </div>
           <div>
            <label htmlFor="edit-deckPath" className="block text-sm font-medium text-slate-300 mb-1">
              Baralho:
            </label>
            <div className="relative">
                <FolderTree className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 pointer-events-none" />
                <input
                type="text"
                id="edit-deckPath"
                value={deckPath}
                onChange={(e) => setDeckPath(e.target.value)}
                list="edit-existing-deck-paths"
                className="w-full p-2 pl-10 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500"
                placeholder="Default (ou novo caminho)"
                />
                <datalist id="edit-existing-deck-paths">
                {uniqueDeckPaths.map(path => (
                    <option key={path} value={path} />
                ))}
                </datalist>
            </div>
          </div>
          <div>
            <label htmlFor="edit-initialDifficultyEstimate" className="block text-sm font-medium text-slate-300 mb-1">
              Estimativa Inicial de Dificuldade (Gemini):
            </label>
            <select
              id="edit-initialDifficultyEstimate"
              value={initialDifficultyEstimate}
              onChange={(e) => setInitialDifficultyEstimate(e.target.value as 'fácil' | 'média' | 'difícil')}
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500"
            >
              <option value="fácil">Fácil</option>
              <option value="média">Média</option>
              <option value="difícil">Difícil</option>
            </select>
          </div>
          <div>
            <label htmlFor="edit-tags" className="block text-sm font-medium text-slate-300 mb-1">
              Tags (separadas por vírgula):
            </label>
            <input
              id="edit-tags"
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500"
              placeholder="ex: biologia, enem, importante"
            />
          </div>
            <div className="flex items-center">
                <input
                id="edit-htmlContent"
                type="checkbox"
                checked={htmlContent}
                onChange={(e) => setHtmlContent(e.target.checked)}
                className="h-4 w-4 text-sky-600 border-slate-500 rounded focus:ring-sky-500"
                />
                <label htmlFor="edit-htmlContent" className="ml-2 block text-sm text-slate-300 flex items-center">
                    <Code size={16} className="mr-1.5 text-sky-400"/>Conteúdo HTML (marcar se a pergunta/resposta usa HTML)
                </label>
            </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-md transition-colors flex items-center"
            >
              <Save size={18} className="mr-2" /> Salvar Flashcard
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditFlashcardModal;
