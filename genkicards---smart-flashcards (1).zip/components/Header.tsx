
import React from 'react';
import { AppView } from '../types';
import { Home, PlusCircle, Mic, Brain, Edit3, Settings } from 'lucide-react'; // Added Edit3

interface HeaderProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

const NavButton: React.FC<{
  onClick: () => void;
  isActive: boolean;
  Icon: React.ElementType;
  label: string;
}> = ({ onClick, isActive, Icon, label }) => (
  <button
    onClick={onClick}
    className={`flex items-center px-3 py-2 sm:px-4 sm:py-2 rounded-lg transition-all duration-200 ease-in-out text-sm sm:text-base
                ${isActive
                  ? 'bg-sky-500 text-white shadow-lg transform scale-105'
                  : 'bg-slate-700 hover:bg-sky-600 text-slate-300 hover:text-white'
                }`}
    aria-current={isActive ? 'page' : undefined}
  >
    <Icon className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
    {label}
  </button>
);

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  return (
    <header className="w-full max-w-4xl bg-slate-800 shadow-xl rounded-xl p-4">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-2xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300 mb-4 sm:mb-0">
          GenkiCards ✨
        </h1>
        <nav className="flex flex-wrap justify-center space-x-1 sm:space-x-2">
          <NavButton onClick={() => setView(AppView.HOME)} isActive={currentView === AppView.HOME} Icon={Home} label="Home" />
          <NavButton onClick={() => setView(AppView.CREATE_AUTOMATIC)} isActive={currentView === AppView.CREATE_AUTOMATIC} Icon={PlusCircle} label="Auto" />
          <NavButton onClick={() => setView(AppView.CREATE_MANUAL)} isActive={currentView === AppView.CREATE_MANUAL} Icon={Edit3} label="Manual" />
          <NavButton onClick={() => setView(AppView.VOICE_MODE)} isActive={currentView === AppView.VOICE_MODE} Icon={Mic} label="Voice" />
          <NavButton onClick={() => setView(AppView.REVIEW)} isActive={currentView === AppView.REVIEW} Icon={Brain} label="Review" />
          {/* <NavButton onClick={() => setView(AppView.SETTINGS)} isActive={currentView === AppView.SETTINGS} Icon={Settings} label="Settings" /> */}
        </nav>
      </div>
    </header>
  );
};

export default Header;