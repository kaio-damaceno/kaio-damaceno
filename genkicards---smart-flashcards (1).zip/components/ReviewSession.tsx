
import React, { useState, useEffect, useCallback } from 'react';
import { Flashcard, ReviewQuality, AppView, CardState } from '../types';
import { updateCardUltraMemo } from '../services/ultraMemoService'; // Changed from sm3Service
import { getCardState } from '../services/deckService';
import { MAX_DAILY_REVIEW_LIMIT, LEARNING_STABILITY_THRESHOLD_DAYS } from '../constants';
import { ChevronLeft, ChevronRight, Eye, EyeOff, RotateCcw, Check, Zap, AlertTriangle, Info, FolderTree, Activity, Thermometer, TrendingUp, Clock } from 'lucide-react';
import { marked } from 'marked';

interface ReviewSessionProps {
  initialBatch: Flashcard[];
  allFlashcards: Flashcard[];
  onUpdateFlashcard: (updatedCard: Flashcard) => void;
  setView: (view: AppView) => void;
  reviewFilterPath: string | null;
  setReviewFilterPath: (path: string | null) => void;
}

const ReviewSession: React.FC<ReviewSessionProps> = ({ 
    initialBatch,
    allFlashcards, 
    onUpdateFlashcard, 
    setView, 
    reviewFilterPath,
    setReviewFilterPath 
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [sessionComplete, setSessionComplete] = useState(false);
  const [currentOverallDueCount, setCurrentOverallDueCount] = useState(0);
  const [cardStartTime, setCardStartTime] = useState<number>(0);

  useEffect(() => {
    setCurrentIndex(0);
    setShowAnswer(false);
    setSessionComplete(!initialBatch || initialBatch.length === 0);
    if (initialBatch && initialBatch.length > 0) {
      setCardStartTime(Date.now()); // Start timer for the first card
    }
  }, [initialBatch]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    let V_filteredByDeckPath = allFlashcards; 
    if (reviewFilterPath) {
      V_filteredByDeckPath = allFlashcards.filter(card => 
        card.deckPath && (card.deckPath === reviewFilterPath || card.deckPath.startsWith(reviewFilterPath + "::"))
      );
    }
    const V_dueCards = V_filteredByDeckPath.filter(card => getCardState(card, today, LEARNING_STABILITY_THRESHOLD_DAYS) !== CardState.NOT_DUE);
    setCurrentOverallDueCount(V_dueCards.length);
  }, [allFlashcards, reviewFilterPath]);


  const handleReview = useCallback((quality: ReviewQuality) => {
    if (!initialBatch || currentIndex >= initialBatch.length) return;

    const responseTimeSeconds = (Date.now() - cardStartTime) / 1000;
    const V_currentCardFromBatch = initialBatch[currentIndex];
    // Call UltraMemo update function
    const updatedCard = updateCardUltraMemo(V_currentCardFromBatch, quality, responseTimeSeconds);
    onUpdateFlashcard(updatedCard); 

    setShowAnswer(false);

    if (currentIndex < initialBatch.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setCardStartTime(Date.now()); // Reset timer for the next card
    } else {
      setSessionComplete(true); 
    }
  }, [currentIndex, initialBatch, onUpdateFlashcard, cardStartTime]);
  
  const handleEndSession = () => {
    setReviewFilterPath(null); 
    setView(AppView.HOME);
  };

  const renderCardContent = (content: string, isHtml: boolean | undefined) => {
    if (isHtml) {
      return <div dangerouslySetInnerHTML={{ __html: content }} />;
    }
    const markdownToHtml = marked.parse(content) as string;
    return <div className="markdown-content" dangerouslySetInnerHTML={{ __html: markdownToHtml }} />;
  };

  const handleShowAnswer = () => {
    setShowAnswer(true);
    // Timer for response stops when a quality button is pressed, not when answer is shown.
    // If you want to measure reading time of answer, a new timer would be needed.
  };
  
  const navigateCard = (direction: 'next' | 'prev') => {
    setShowAnswer(false);
    setCardStartTime(Date.now());
    if (direction === 'next') {
        setCurrentIndex(prev => Math.min(initialBatch.length - 1, prev + 1));
    } else {
        setCurrentIndex(prev => Math.max(0, prev - 1));
    }
  };


  if (allFlashcards.length === 0) { 
     return (
      <div className="bg-slate-800 p-8 rounded-xl shadow-2xl text-center animate-fadeIn">
        <Check size={64} className="mx-auto text-sky-400 mb-6" />
        <h2 className="text-3xl font-semibold text-slate-100 mb-4">No Flashcards Yet!</h2>
        <p className="text-slate-300 mb-6">Create or import some flashcards to start learning.</p>
        <button onClick={handleEndSession} className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors">
          Back to Home
        </button>
      </div>
    );
  }

  if (sessionComplete) {
    return (
      <div className="bg-slate-800 p-8 rounded-xl shadow-2xl text-center animate-fadeIn">
        <Zap size={64} className="mx-auto text-green-400 mb-6" />
        <h2 className="text-3xl font-semibold text-slate-100 mb-4">
            {reviewFilterPath ? `Deck Review Complete!` : `Session Complete!`}
        </h2>
        <p className="text-slate-300 mb-6">
            {initialBatch.length > 0 ? `You've reviewed this batch of ${initialBatch.length} card${initialBatch.length === 1 ? '' : 's'}.` 
                                    : (reviewFilterPath ? `No cards were due for review in this deck.` : `No cards were due for this session.`)}
            Great job!
        </p>
        {currentOverallDueCount > 0 && ( 
             <p className="text-sm text-sky-300 mb-4">
                {currentOverallDueCount} more card{currentOverallDueCount === 1 ? '' : 's'} are due {reviewFilterPath ? `in this deck/filter` : `overall`}. You can start a new session to review them.
            </p>
        )}
        <button onClick={handleEndSession} className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors">
          Back to Home
        </button>
      </div>
    );
  }
  
  const currentCard = initialBatch[currentIndex];
  if (!currentCard) {
      return (
           <div className="bg-slate-800 p-8 rounded-xl shadow-2xl text-center animate-fadeIn">
             <AlertTriangle size={64} className="mx-auto text-red-400 mb-6" />
             <h2 className="text-3xl font-semibold text-slate-100 mb-4">Error</h2>
             <p className="text-slate-300 mb-6">Could not load the current card. The review batch might be empty or an issue occurred.</p>
             <button onClick={handleEndSession} className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors">
              Back to Home
            </button>
           </div>
      );
  }

  const qualityButtons = [
    { label: "Errei (Quase)", quality: ReviewQuality.IncorrectEasy, color: "bg-red-500 hover:bg-red-600", title: "Errei, mas parecia fácil." },
    { label: "Errei (Difícil)", quality: ReviewQuality.IncorrectHard, color: "bg-red-700 hover:bg-red-800", title: "Errei, e realmente é difícil." },
    { label: "Difícil", quality: ReviewQuality.CorrectHard, color: "bg-orange-500 hover:bg-orange-600", title: "Acertei, mas com muita dificuldade." },
    { label: "Bom", quality: ReviewQuality.CorrectHesitation, color: "bg-yellow-500 hover:bg-yellow-600", title: "Acertei, com alguma hesitação." },
    { label: "Fácil", quality: ReviewQuality.Perfect, color: "bg-green-500 hover:bg-green-600", title: "Acertei, com perfeição!" },
  ];
  // Special "Blackout" button, if needed (maps to a high D_user usually)
  // { label: "Apagão!", quality: ReviewQuality.Blackout, color: "bg-black hover:bg-gray-900", title: "Não lembrei de nada!" }


  return (
    <div className="bg-slate-800 p-6 md:p-8 rounded-xl shadow-2xl w-full animate-fadeIn">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-2xl font-semibold text-sky-300">Review Session ({currentIndex + 1} / {initialBatch.length})</h2>
        <button onClick={handleEndSession} className="text-slate-400 hover:text-sky-400 transition-colors flex items-center">
          <RotateCcw size={20} /> <span className="ml-1 hidden sm:inline">End Session</span>
        </button>
      </div>
      {initialBatch.length === MAX_DAILY_REVIEW_LIMIT && currentOverallDueCount > MAX_DAILY_REVIEW_LIMIT && (
        <div className="bg-sky-700 border border-sky-600 text-sky-200 px-4 py-2 rounded-md mb-4 flex items-center text-sm" role="status">
            <Info size={18} className="mr-2" />
            Showing {initialBatch.length} of {currentOverallDueCount} cards due {reviewFilterPath ? `in this deck/filter` : `overall`} to manage daily load.
        </div>
      )}
       {currentCard.deckPath && currentCard.deckPath !== "Default" && (
        <p className="text-xs text-sky-400 mb-3 flex items-center">
          <FolderTree size={14} className="mr-1 opacity-70" />
          Deck: {currentCard.deckPath.split('::').join(' / ')}
        </p>
      )}

      <div className={`min-h-[200px] bg-slate-700 p-6 rounded-lg shadow-inner flex flex-col justify-center items-start text-left transition-all duration-300 ${showAnswer ? 'border-sky-500 border-2' : 'border-transparent border-2'}`}>
        <div className="text-xl md:text-2xl text-slate-100 mb-4 w-full">{renderCardContent(currentCard.pergunta, currentCard.htmlContent)}</div>
        {showAnswer && (
          <div className="animate-fadeIn mt-4 pt-4 border-t border-slate-600 w-full space-y-2">
            <div className="text-lg md:text-xl text-green-300 w-full">{renderCardContent(currentCard.resposta, currentCard.htmlContent)}</div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1 text-xs text-slate-400 pt-2">
                <div className="flex items-center" title="Estabilidade (S): Dias até o próximo esquecimento estimado."><TrendingUp size={14} className="mr-1.5 text-lime-400"/> S: {currentCard.stability.toFixed(1)}d</div>
                <div className="flex items-center" title="Dificuldade (D): Quão difícil o card é (0-1)."><Thermometer size={14} className="mr-1.5 text-amber-400"/> D: {currentCard.difficulty.toFixed(2)}</div>
                <div className="flex items-center" title="Próxima Revisão"><Clock size={14} className="mr-1.5 text-sky-400"/> Prox.: {new Date(currentCard.nextReviewDate).toLocaleDateString()}</div>
                <div className="flex items-center" title="Acertos Consecutivos (A)"><Check size={14} className="mr-1.5 text-green-400"/> A: {currentCard.consecutiveCorrectAnswers}</div>
                 {currentCard.lastResponseTimeSeconds !== undefined && 
                    <div className="flex items-center" title="Último Tempo de Resposta (T)">
                        <Activity size={14} className="mr-1.5 text-purple-400"/> T: {currentCard.lastResponseTimeSeconds.toFixed(1)}s
                    </div>
                  }
            </div>
             {currentCard.htmlContent && <p className="text-xs text-amber-400 mt-1">Note: Card contém HTML.</p>}
          </div>
        )}
      </div>

      <div className="mt-8">
        {!showAnswer ? (
          <button
            onClick={handleShowAnswer}
            className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors flex items-center justify-center text-lg"
          >
            <Eye className="mr-2" /> Mostrar Resposta
          </button>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 sm:gap-3">
            {qualityButtons.map(btn => (
              <button
                key={btn.quality}
                onClick={() => handleReview(btn.quality)}
                title={btn.title}
                className={`w-full ${btn.color} text-white font-medium py-3 px-2 sm:px-3 rounded-lg shadow-md transition-transform hover:scale-105 text-xs sm:text-sm`}
              >
                {btn.label}
              </button>
            ))}
             <button
                key={ReviewQuality.Blackout}
                onClick={() => handleReview(ReviewQuality.Blackout)}
                title="Não lembrei de nada!"
                className={`w-full bg-black hover:bg-gray-800 text-white font-medium py-3 px-2 sm:px-3 rounded-lg shadow-md transition-transform hover:scale-105 text-xs sm:text-sm col-span-2 sm:col-span-1 lg:col-auto`}
              >
                Apagão!
              </button>
          </div>
        )}
      </div>
      
       <div className="flex justify-between items-center mt-8 text-slate-400">
        <button 
            onClick={() => navigateCard('prev')}
            disabled={currentIndex === 0}
            className="p-2 hover:text-sky-300 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Card Anterior"
        >
            <ChevronLeft size={24} />
        </button>
        <p className="text-sm">Card {currentIndex + 1} de {initialBatch.length}</p>
        <button 
            onClick={() => navigateCard('next')}
            disabled={currentIndex === initialBatch.length - 1 || sessionComplete}
            className="p-2 hover:text-sky-300 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Próximo Card"
        >
            <ChevronRight size={24} />
        </button>
       </div>

    </div>
  );
};

export default ReviewSession;
