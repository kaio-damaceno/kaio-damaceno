import React, { useState } from 'react';
import { DeckNodeData } from '../types';
import { ChevronDown, ChevronRight, Folder, MoreVertical, Edit2, Trash2, Eye, FolderPlus } from 'lucide-react';

interface RecursiveDeckRowProps {
    node: DeckNodeData;
    onReviewDeck: (deckPath: string) => void;
    onViewDeckDetails: (deckPath: string) => void;
    onEditDeck: (deckNode: DeckNodeData) => void;
    onDeleteDeck: (deckNode: DeckNodeData) => void;
    onOpenCreateDeckModal: (defaultParent?: string) => void; // Added prop
    level: number;
    expandedDecks: Record<string, boolean>;
    toggleExpand: (deckPath: string) => void;
}

const RecursiveDeckRow: React.FC<RecursiveDeckRowProps> = ({ 
    node, onReviewDeck, onViewDeckDetails, onEditDeck, onDeleteDeck, 
    onOpenCreateDeckModal, // Destructure prop
    level, expandedDecks, toggleExpand 
}) => {
    const isExpanded = !!expandedDecks[node.fullPath];
    const hasChildren = node.children && node.children.length > 0;
    const totalDueInNode = node.stats.newCardsDue + node.stats.learningCardsDue + node.stats.reviewCardsDue;
    const [showOptions, setShowOptions] = useState(false);

    const handleOptionsClick = (e: React.MouseEvent) => {
        e.stopPropagation(); // Prevent row click event
        setShowOptions(prev => !prev);
    };
    
    const handleActionClick = (e: React.MouseEvent, action: () => void) => {
        e.stopPropagation();
        action();
        setShowOptions(false);
    };

    return (
        <div className="relative"> {/* Container for potential absolute positioned options menu */}
            <div className={`
              flex items-center py-2.5 border-b border-slate-700/50
              ${level > 0 ? 'hover:bg-slate-700/40' : 'hover:bg-slate-700/20'}
              transition-colors duration-150
            `}
            style={{ paddingLeft: `${level * 12 + (hasChildren ? 0 : 18)}px` }} // Indent further if no expand icon
            >
                {/* Expand/Collapse and Deck Name */}
                <div 
                  className="flex items-center flex-grow min-w-0 cursor-pointer mr-2" 
                  onClick={() => hasChildren ? toggleExpand(node.fullPath) : onViewDeckDetails(node.fullPath)}
                  title={hasChildren ? (isExpanded ? `Collapse ${node.name}` : `Expand ${node.name}`) : `View cards in ${node.name}`}
                >
                    {hasChildren && (
                        isExpanded ? <ChevronDown size={18} className="mr-1.5 text-slate-400 flex-shrink-0" /> : <ChevronRight size={18} className="mr-1.5 text-slate-400 flex-shrink-0" />
                    )}
                    {/* <Folder size={16} className={`mr-1.5 ${level === 0 ? 'text-sky-400' : 'text-sky-500'} flex-shrink-0`} /> */}
                    <span className="text-slate-100 truncate text-sm sm:text-base" >{node.name}</span>
                    {node.stats.totalCardsInHierarchy > 0 && (
                      <span className="ml-2 text-xs text-slate-500">({node.stats.progressPercent}%)</span>
                    )}
                </div>

                {/* Card Counts */}
                 <div 
                    className={`w-10 sm:w-12 text-center text-sm font-medium ${node.stats.newCardsDue > 0 ? 'text-blue-400 hover:text-blue-300' : 'text-slate-600'} ${node.stats.newCardsDue > 0 ? 'cursor-pointer' : 'cursor-default'}`}
                    onClick={(e) => { e.stopPropagation(); if (node.stats.newCardsDue > 0) onReviewDeck(node.fullPath); }}
                    title={`${node.stats.newCardsDue} New Cards Due`}
                >
                    {node.stats.newCardsDue}
                </div>
                <div 
                     className={`w-10 sm:w-12 text-center text-sm font-medium ${node.stats.learningCardsDue > 0 ? 'text-orange-400 hover:text-orange-300' : 'text-slate-600'} ${node.stats.learningCardsDue > 0 ? 'cursor-pointer' : 'cursor-default'}`}
                    onClick={(e) => { e.stopPropagation(); if (node.stats.learningCardsDue > 0) onReviewDeck(node.fullPath); }}
                    title={`${node.stats.learningCardsDue} Learning Cards Due`}
                >
                    {node.stats.learningCardsDue}
                </div>
                <div 
                    className={`w-10 sm:w-12 text-center text-sm font-medium ${node.stats.reviewCardsDue > 0 ? 'text-green-400 hover:text-green-300' : 'text-slate-600'} ${node.stats.reviewCardsDue > 0 ? 'cursor-pointer' : 'cursor-default'}`}
                    onClick={(e) => { e.stopPropagation(); if (node.stats.reviewCardsDue > 0) onReviewDeck(node.fullPath); }}
                    title={`${node.stats.reviewCardsDue} Graduated Cards Due`}
                >
                    {node.stats.reviewCardsDue}
                </div>

                {/* Options Button */}
                <div className="w-8 sm:w-10 text-center flex-shrink-0 relative">
                    <button 
                        onClick={handleOptionsClick}
                        className="p-1 rounded-full hover:bg-slate-600 text-slate-400 hover:text-slate-200"
                        aria-label={`Options for deck ${node.name}`}
                        title={`Options for ${node.name}`}
                    >
                        <MoreVertical size={18} />
                    </button>
                    {showOptions && (
                        <div 
                            className="absolute right-0 mt-1 w-48 bg-slate-700 border border-slate-600 rounded-md shadow-lg py-1 z-20"
                            onMouseLeave={() => setShowOptions(false)} // Close if mouse leaves menu
                        >
                            <button onClick={(e) => handleActionClick(e, () => onViewDeckDetails(node.fullPath))} 
                                    className="w-full text-left px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-600 flex items-center">
                                <Eye size={14} className="mr-2"/> Ver Cards
                            </button>
                            <button onClick={(e) => handleActionClick(e, () => onOpenCreateDeckModal(node.fullPath))} 
                                    className="w-full text-left px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-600 flex items-center">
                                <FolderPlus size={14} className="mr-2"/> Criar Sub-baralho
                            </button>
                            <button onClick={(e) => handleActionClick(e, () => onEditDeck(node))} 
                                    className="w-full text-left px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-600 flex items-center">
                                <Edit2 size={14} className="mr-2"/> Renomear Baralho
                            </button>
                            <button onClick={(e) => handleActionClick(e, () => onDeleteDeck(node))} 
                                    className="w-full text-left px-3 py-1.5 text-sm text-red-400 hover:bg-red-600 hover:text-red-200 flex items-center">
                                <Trash2 size={14} className="mr-2"/> Excluir Baralho
                            </button>
                        </div>
                    )}
                </div>
            </div>
            {hasChildren && isExpanded && (
                <div className="deck-children">
                    {node.children.map(childNode => (
                        <RecursiveDeckRow
                            key={childNode.fullPath}
                            node={childNode}
                            onReviewDeck={onReviewDeck}
                            onViewDeckDetails={onViewDeckDetails}
                            onEditDeck={onEditDeck}
                            onDeleteDeck={onDeleteDeck}
                            onOpenCreateDeckModal={onOpenCreateDeckModal} // Pass down
                            level={level + 1}
                            expandedDecks={expandedDecks}
                            toggleExpand={toggleExpand}
                        />
                    ))}
                </div>
            )}
        </div>
    );
};


interface DeckTreeViewProps {
  deckTree: DeckNodeData[];
  onReviewDeck: (deckPath: string) => void;
  onViewDeckDetails: (deckPath: string) => void;
  onEditDeck: (deckNode: DeckNodeData) => void;
  onDeleteDeck: (deckNode: DeckNodeData) => void;
  onOpenCreateDeckModal: (defaultParent?: string) => void; // Added prop
}

const DeckTreeView: React.FC<DeckTreeViewProps> = ({ 
    deckTree, 
    onReviewDeck, 
    onViewDeckDetails, 
    onEditDeck, 
    onDeleteDeck,
    onOpenCreateDeckModal // Destructure prop
}) => {
  const [expandedDecks, setExpandedDecks] = useState<Record<string, boolean>>(() => {
    const initialExpanded: Record<string, boolean> = {};
    deckTree.forEach(node => {
      initialExpanded[node.fullPath] = true; 
      //   if (node.children && node.children.length > 0) { 
      //       node.children.forEach(child => initialExpanded[child.fullPath] = true); // Optionally expand second level
      //   }
    });
    return initialExpanded;
  });

  const toggleExpand = (deckPath: string) => {
    setExpandedDecks(prev => ({ ...prev, [deckPath]: !prev[deckPath] }));
  };

  if (!deckTree || deckTree.length === 0) {
    // This case should ideally be handled by HomeView's loading/empty states
    return null; 
  }

  return (
    <div className="bg-slate-800 rounded-lg">
      {/* Header Row */}
      <div className="flex items-center py-2.5 px-2 border-b-2 border-slate-600 sticky top-0 bg-slate-800 z-10">
        <div className="flex-grow min-w-0 text-slate-300 font-semibold text-sm sm:text-base pl-1">Baralho (% Dominado)</div>
        <div className="w-10 sm:w-12 text-center text-blue-400 font-semibold text-sm">Novo</div>
        <div className="w-10 sm:w-12 text-center text-orange-400 font-semibold text-sm">Aprender</div>
        <div className="w-10 sm:w-12 text-center text-green-400 font-semibold text-sm">Revisar</div>
        <div className="w-8 sm:w-10 text-center text-slate-500 font-semibold text-xs">Opções</div>
      </div>
      {/* Deck Rows */}
      <div className="max-h-[calc(100vh-300px)] sm:max-h-[calc(100vh-280px)] overflow-y-auto custom-scrollbar"> {/* Adjusted height */}
        {deckTree.map(node => (
          <RecursiveDeckRow
            key={node.fullPath}
            node={node}
            onReviewDeck={onReviewDeck}
            onViewDeckDetails={onViewDeckDetails}
            onEditDeck={onEditDeck}
            onDeleteDeck={onDeleteDeck}
            onOpenCreateDeckModal={onOpenCreateDeckModal} // Pass down
            level={0}
            expandedDecks={expandedDecks}
            toggleExpand={toggleExpand}
          />
        ))}
      </div>
    </div>
  );
};

export default DeckTreeView;
