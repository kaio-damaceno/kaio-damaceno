import React, { useState, useEffect } from 'react';
import { Save, XCircle, FolderTree, ListTree } from 'lucide-react';

interface CreateDeckModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmCreateDeck: (fullNewDeckPath: string) => void;
  existingDeckPaths: string[];
  defaultParentPath?: string | null;
}

const CreateDeckModal: React.FC<CreateDeckModalProps> = ({
  isOpen,
  onClose,
  onConfirmCreateDeck,
  existingDeckPaths,
  defaultParentPath,
}) => {
  const [newDeckName, setNewDeckName] = useState('');
  const [selectedParentPath, setSelectedParentPath] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setNewDeckName('');
      setSelectedParentPath(defaultParentPath || '');
      setError(null);
    }
  }, [isOpen, defaultParentPath]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const trimmedName = newDeckName.trim();

    if (!trimmedName) {
      setError("O nome do baralho não pode estar vazio.");
      return;
    }
    if (trimmedName.includes("::")) {
      setError("O nome do baralho não pode conter '::'.");
      return;
    }

    const fullNewDeckPath = selectedParentPath ? `${selectedParentPath}::${trimmedName}` : trimmedName;
    
    // Check if this exact path already exists as a segment of another path or fully.
    // This is a bit tricky because "Parent" could exist if "Parent::Child" exists.
    // We are primarily concerned if the *exact* fullNewDeckPath being created already exists.
    if (existingDeckPaths.includes(fullNewDeckPath)) {
        // A simple check: if the full path already exists directly.
        // More complex checks (e.g. if "A" is created when "A::B" exists) are implicitly handled by how decks are displayed.
        // The main goal here is to guide user to add a card to this path.
    }

    onConfirmCreateDeck(fullNewDeckPath);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-slate-900 bg-opacity-75 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-slate-800 p-6 rounded-lg shadow-xl w-full max-w-md animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-sky-300">
            {defaultParentPath ? "Criar Sub-baralho" : "Criar Novo Baralho"}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <XCircle size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {defaultParentPath && (
            <div>
              <label className="block text-sm font-medium text-slate-400">
                Dentro do Baralho Pai:
              </label>
              <p className="text-slate-200 bg-slate-700 px-3 py-2 rounded-md">{defaultParentPath}</p>
            </div>
          )}

          {!defaultParentPath && (
            <div>
              <label htmlFor="parentDeckPath" className="block text-sm font-medium text-slate-300 mb-1">
                Baralho Pai (Opcional):
              </label>
              <div className="relative">
                <ListTree className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 pointer-events-none" />
                <select
                  id="parentDeckPath"
                  value={selectedParentPath}
                  onChange={(e) => setSelectedParentPath(e.target.value)}
                  className="w-full p-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none text-slate-100"
                >
                  <option value="">Nenhum (Baralho Principal)</option>
                  {existingDeckPaths.map(path => (
                    <option key={path} value={path}>{path.split("::").join(" / ")}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
          
          <div>
            <label htmlFor="newDeckName" className="block text-sm font-medium text-slate-300 mb-1">
              Nome do Novo Baralho {defaultParentPath ? " (Sub-baralho)" : ""}:
            </label>
             <div className="relative">
                <FolderTree className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 pointer-events-none" />
                <input
                id="newDeckName"
                type="text"
                value={newDeckName}
                onChange={(e) => setNewDeckName(e.target.value)}
                className="w-full p-3 pl-10 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none text-slate-100 placeholder-slate-400"
                placeholder={defaultParentPath ? "Nome do Sub-baralho" : "Nome do Baralho Principal"}
                required
                autoFocus
                />
            </div>
          </div>

          {error && <p className="text-sm text-red-400 animate-shake">{error}</p>}

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-md transition-colors flex items-center"
            >
              <Save size={18} className="mr-2" /> Continuar e Adicionar Card
            </button>
          </div>
        </form>
         <p className="text-xs text-slate-400 mt-4 text-center">
            Após confirmar, você será direcionado para adicionar o primeiro card a este novo caminho de baralho.
          </p>
      </div>
    </div>
  );
};

export default CreateDeckModal;
