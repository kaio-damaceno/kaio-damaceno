
import React, { useState, useEffect, useCallback } from 'react';
import { InputType, GeneratedFlashcardPayload } from '../types';
import { generateQuestionsFromText, createFlashcardFromSpokenAnswer } from '../services/geminiService';
import useSpeechRecognition from '../hooks/useSpeechRecognition';
import LoadingSpinner from './LoadingSpinner';
import { Mic, Send, CheckCircle, XCircle, AlertTriangle, Wand2 } from 'lucide-react';

interface VoiceModeViewProps {
  addFlashcards: (cardsData: GeneratedFlashcardPayload[], sourceType: InputType, sourceInfo?: string) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  // Fix: Add error prop to VoiceModeViewProps
  error: string | null;
  setError: (error: string | null) => void;
  isApiKeySet: boolean;
}

enum VoiceStep {
  Explain,
  GeneratingQuestions,
  AnswerQuestions,
  GeneratingCards,
  Done,
}

// Fix: Destructure error prop
const VoiceModeView: React.FC<VoiceModeViewProps> = ({ addFlashcards, isLoading, setIsLoading, error, setError, isApiKeySet }) => {
  const [step, setStep] = useState<VoiceStep>(VoiceStep.Explain);
  const [explanation, setExplanation] = useState('');
  const [questions, setQuestions] = useState<string[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [isAllowedMic, setIsAllowedMic] = useState<boolean | null>(null);

  const {
    transcript,
    isListening,
    startListening,
    stopListening,
    error: speechError,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  useEffect(() => {
    if (speechError) {
      setError(`Speech recognition error: ${speechError}`);
      if (speechError.includes('permission')) setIsAllowedMic(false);
    } else {
      // If no error, assume permission was granted previously or not yet determined
      // This doesn't mean permission IS granted, just that there's no permission error *yet*
    }
  }, [speechError, setError]);

  useEffect(() => {
     // Check initial microphone permission status
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'microphone' as PermissionName }).then((permissionStatus) => {
        setIsAllowedMic(permissionStatus.state === 'granted');
        permissionStatus.onchange = () => {
          setIsAllowedMic(permissionStatus.state === 'granted');
        };
      });
    }
  }, []);


  const handleStartExplanation = () => {
    if (!browserSupportsSpeechRecognition) {
        setError("Your browser doesn't support speech recognition. Try Chrome or Edge.");
        return;
    }
    if (isAllowedMic === false) {
        setError("Microphone permission denied. Please enable it in your browser settings.");
        return;
    }
    setExplanation('');
    resetTranscript();
    startListening();
  };

  const handleStopExplanation = useCallback(() => {
    stopListening();
    setExplanation(prev => prev + (transcript.endsWith('.') || transcript.endsWith('?') || transcript.endsWith('!') || transcript.length === 0 ? transcript : transcript + '. '));
    resetTranscript();
  }, [stopListening, transcript, resetTranscript]);
  
  useEffect(() => {
    if (!isListening && step === VoiceStep.Explain && transcript) {
        // Append continuously if user pauses and resumes
        setExplanation(prev => prev + (transcript.endsWith('.') || transcript.endsWith('?') || transcript.endsWith('!') || transcript.length === 0 ? transcript : transcript + '. '));
        resetTranscript();
    }
  }, [transcript, isListening, step, resetTranscript]);


  const handleProcessExplanation = async () => {
    handleStopExplanation(); // Ensure any final transcript is captured
    const finalExplanation = explanation + (transcript.endsWith('.') || transcript.endsWith('?') || transcript.endsWith('!') || transcript.length === 0 ? transcript : transcript + '. ');
    
    if (!finalExplanation.trim() || finalExplanation.trim().length < 20) { // Added length check
      setError("Explanation is too short. Please provide more details.");
      return;
    }
     if (!isApiKeySet) {
      setError("API Key is not configured. Cannot generate questions.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setStep(VoiceStep.GeneratingQuestions);
    try {
      const generatedQs = await generateQuestionsFromText(finalExplanation);
      if (generatedQs.length === 0) {
        setError("Could not generate questions from your explanation. Please try rephrasing or adding more detail.");
        setStep(VoiceStep.Explain);
      } else {
        setQuestions(generatedQs);
        setAnswers(new Array(generatedQs.length).fill(''));
        setCurrentQuestionIndex(0);
        setStep(VoiceStep.AnswerQuestions);
      }
    } catch (err) {
      console.error(err);
      setError((err as Error).message || 'Failed to generate questions.');
      setStep(VoiceStep.Explain);
    } finally {
      setIsLoading(false);
      resetTranscript();
    }
  };

  const handleStartAnswer = () => {
     if (!browserSupportsSpeechRecognition || isAllowedMic === false) return;
    resetTranscript();
    startListening();
  };

  const handleStopAnswerAndNext = async () => {
    stopListening();
    const currentAnswer = transcript;
    const updatedAnswers = [...answers];
    updatedAnswers[currentQuestionIndex] = currentAnswer;
    setAnswers(updatedAnswers);
    resetTranscript();

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // All questions answered, generate flashcards
      setStep(VoiceStep.GeneratingCards);
      setIsLoading(true);
      setError(null);
      try {
        const finalFlashcards: GeneratedFlashcardPayload[] = [];
        for (let i = 0; i < questions.length; i++) {
          if (updatedAnswers[i].trim()) { // Only create card if answer is not empty
            const card = await createFlashcardFromSpokenAnswer(questions[i], updatedAnswers[i], explanation);
            finalFlashcards.push(card);
          }
        }
        if (finalFlashcards.length > 0) {
            addFlashcards(finalFlashcards, InputType.VOICE_EXPLANATION, "User's Explanation");
            setStep(VoiceStep.Done);
        } else {
            setError("No flashcards were created. Answers might have been too short or unclear.");
            setStep(VoiceStep.Explain); // Go back to start if no cards
        }
      } catch (err) {
        console.error(err);
        setError((err as Error).message || 'Failed to create flashcards from answers.');
        setStep(VoiceStep.AnswerQuestions); // Stay on answer step if error
      } finally {
        setIsLoading(false);
      }
    }
  };
  
  const resetVoiceMode = () => {
    setStep(VoiceStep.Explain);
    setExplanation('');
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setAnswers([]);
    resetTranscript();
    setError(null);
  };

  if (!browserSupportsSpeechRecognition) {
    return <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md"><p>Your browser does not support speech recognition. Please try Chrome or Edge.</p></div>;
  }
  
  if (isAllowedMic === false) {
    return <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md"><p>Microphone access is denied. Please enable microphone permissions in your browser settings to use Voice Mode.</p></div>;
  }


  return (
    <div className="bg-slate-800 p-6 md:p-8 rounded-xl shadow-2xl animate-fadeIn space-y-6">
      <h2 className="text-3xl font-semibold text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
        Interactive Voice Mode
      </h2>
      
      {!isApiKeySet && step !== VoiceStep.Explain && (
        <div className="bg-red-600 border border-red-700 text-white px-4 py-3 rounded-lg relative mb-4 flex items-center" role="alert">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <span className="block sm:inline">API Key not set. AI features are disabled.</span>
        </div>
      )}

      {/* Step: Explain */}
      {step === VoiceStep.Explain && (
        <div className="space-y-4">
          <p className="text-slate-300 text-center">
            {isListening ? "Listening... Explain your topic clearly." : "Press the microphone and start explaining a topic. The AI will generate questions based on your explanation."}
          </p>
          <div className="bg-slate-700 p-4 rounded-lg min-h-[100px] text-slate-200">
            {explanation + transcript}
          </div>
          <div className="flex justify-center space-x-4">
            <button
              onClick={isListening ? handleStopExplanation : handleStartExplanation}
              className={`p-4 rounded-full transition-colors duration-200 ${isListening ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-green-500 hover:bg-green-600'}`}
              disabled={isLoading}
            >
              <Mic size={28} className="text-white" />
            </button>
            <button
              onClick={handleProcessExplanation}
              disabled={isLoading || isListening || !explanation.trim() || !isApiKeySet}
              className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md flex items-center justify-center disabled:opacity-50"
            >
              <Send className="mr-2" /> Process Explanation
            </button>
          </div>
        </div>
      )}

      {/* Step: Generating Questions */}
      {step === VoiceStep.GeneratingQuestions && (
        <div className="text-center space-y-4 py-8">
          <LoadingSpinner text="AI is crafting questions based on your explanation..." />
          <p className="text-slate-400">This may take a moment.</p>
        </div>
      )}

      {/* Step: Answer Questions */}
      {step === VoiceStep.AnswerQuestions && questions.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-medium text-sky-300">Question {currentQuestionIndex + 1} of {questions.length}:</h3>
          <p className="text-slate-100 text-lg bg-slate-700 p-4 rounded-md">{questions[currentQuestionIndex]}</p>
          <div className="bg-slate-700 p-4 rounded-lg min-h-[80px] text-slate-200">
            {answers[currentQuestionIndex] + transcript}
          </div>
           <div className="flex justify-center space-x-4">
            <button
              onClick={isListening ? () => { stopListening(); answers[currentQuestionIndex] += transcript; resetTranscript(); } : handleStartAnswer}
              className={`p-4 rounded-full transition-colors duration-200 ${isListening ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-green-500 hover:bg-green-600'}`}
              disabled={isLoading}
            >
              <Mic size={28} className="text-white" />
            </button
            >
            <button
              onClick={handleStopAnswerAndNext}
              disabled={isLoading || isListening || !isApiKeySet}
              className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md flex items-center justify-center disabled:opacity-50"
            >
              {currentQuestionIndex < questions.length - 1 ? "Next Question" : "Finish & Create Cards"} <Send className="ml-2" />
            </button>
          </div>
        </div>
      )}
      
      {/* Step: Generating Cards */}
      {step === VoiceStep.GeneratingCards && (
         <div className="text-center space-y-4 py-8">
          <LoadingSpinner text="AI is creating flashcards from your answers..." />
        </div>
      )}

      {/* Step: Done */}
      {step === VoiceStep.Done && (
        <div className="text-center space-y-6 py-8">
          <CheckCircle size={64} className="mx-auto text-green-500" />
          <h3 className="text-2xl font-semibold text-slate-100">Flashcards Created!</h3>
          <p className="text-slate-300">Your new flashcards from the voice session have been added to your collection.</p>
          <button
            onClick={resetVoiceMode}
            className="bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors"
          >
            Start New Voice Session
          </button>
        </div>
      )}
      
      {/* Error display within Voice Mode */}
       {error && step !== VoiceStep.Done && (
         <div className="bg-red-200 border border-red-400 text-red-800 px-4 py-3 rounded relative mt-4" role="alert">
           <strong className="font-bold">Oops! </strong>
           {/* Fix: Use the error prop passed to the component */}
           <span className="block sm:inline">{error}</span>
           {/* Fix: Use the setError prop passed to the component */}
           <button onClick={() => setError(null)} className="absolute top-0 bottom-0 right-0 px-4 py-3">
             <XCircle className="fill-current h-6 w-6 text-red-600" />
           </button>
         </div>
       )}
    </div>
  );
};

export default VoiceModeView;
