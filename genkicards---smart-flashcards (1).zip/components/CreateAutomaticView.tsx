
import React, { useState, useCallback } from 'react';
import { InputType, Flashcard, GeneratedFlashcardPayload } from '../types';
import { generateFlashcardsFromText, generateFlashcardsFromImage } from '../services/geminiService';
import FileUpload from './FileUpload';
import LoadingSpinner from './LoadingSpinner';
import { Lightbulb, FileText, Image as ImageIcon, Video, AlertTriangle } from 'lucide-react';

interface CreateAutomaticViewProps {
  addFlashcards: (cardsData: GeneratedFlashcardPayload[], sourceType: InputType, sourceInfo?: string) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  isApiKeySet: boolean;
}

type ActiveInput = 'text' | 'image' | 'video';

const CreateAutomaticView: React.FC<CreateAutomaticViewProps> = ({ addFlashcards, isLoading, setIsLoading, setError, isApiKeySet }) => {
  const [activeInput, setActiveInput] = useState<ActiveInput>('text');
  const [textInput, setTextInput] = useState('');
  const [fileInput, setFileInput] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleTextSubmit = async () => {
    if (!textInput.trim()) {
      setError("Please enter some text, a link, or a video transcript.");
      return;
    }
    if (!isApiKeySet) {
      setError("API Key is not configured. Cannot generate flashcards.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const type = activeInput === 'text' ? InputType.TEXT : InputType.VIDEO_TRANSCRIPT;
      const generatedCards = await generateFlashcardsFromText(textInput, type);
      if (generatedCards.length === 0) {
        setError("No flashcards could be generated. The content might be too short or not suitable. Try adding more details or rephrasing.");
      } else {
        addFlashcards(generatedCards, type, type === InputType.TEXT && textInput.startsWith('http') ? textInput.substring(0, 50) + '...' : undefined);
      }
      setTextInput('');
    } catch (err) {
      console.error(err);
      setError((err as Error).message || 'Failed to generate flashcards from text.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageSubmit = async () => {
    if (!fileInput) {
      setError("Please select an image file.");
      return;
    }
     if (!isApiKeySet) {
      setError("API Key is not configured. Cannot generate flashcards.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Image = (reader.result as string).split(',')[1];
        try {
            const generatedCards = await generateFlashcardsFromImage(base64Image, fileInput.type);
            if (generatedCards.length === 0) {
              setError("No flashcards could be generated from the image. The image might not contain enough text or clear content.");
            } else {
              addFlashcards(generatedCards, InputType.IMAGE, fileName || 'uploaded_image');
            }
            setFileInput(null);
            setFileName(null);
        } catch (e) {
            console.error(e);
            setError((e as Error).message || 'Failed to generate flashcards from image.');
        } finally {
            setIsLoading(false);
        }
      };
      reader.onerror = () => {
        setError("Failed to read the image file.");
        setIsLoading(false);
      };
      reader.readAsDataURL(fileInput);
    } catch (err) {
      console.error(err);
      setError((err as Error).message || 'An unexpected error occurred.');
      setIsLoading(false);
    }
  };
  
  const handleSubmit = () => {
    if (activeInput === 'image') {
      handleImageSubmit();
    } else {
      handleTextSubmit();
    }
  };

  const TabButton: React.FC<{ type: ActiveInput; label: string; icon: React.ReactNode }> = ({ type, label, icon }) => (
    <button
      onClick={() => setActiveInput(type)}
      className={`flex-1 sm:flex-none flex items-center justify-center p-3 sm:px-6 sm:py-3 rounded-t-lg transition-colors duration-200
                  ${activeInput === type ? 'bg-sky-600 text-white' : 'bg-slate-700 hover:bg-slate-600 text-slate-300'}`}
    >
      {icon} <span className="ml-2 hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="bg-slate-800 p-6 md:p-8 rounded-xl shadow-2xl animate-fadeIn">
      <h2 className="text-3xl font-semibold mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">
        Create Flashcards Automatically
      </h2>
      
      {!isApiKeySet && (
        <div className="bg-red-600 border border-red-700 text-white px-4 py-3 rounded-lg relative mb-6 flex items-center" role="alert">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <span className="block sm:inline">API Key not set. Flashcard generation is disabled.</span>
        </div>
      )}

      <div className="flex mb-1 border-b border-slate-600">
        <TabButton type="text" label="Text / Link" icon={<FileText size={18} />} />
        <TabButton type="image" label="Image / PDF Page" icon={<ImageIcon size={18} />} />
        <TabButton type="video" label="Video Transcript" icon={<Video size={18} />} />
      </div>

      <div className="mt-6 space-y-6">
        {activeInput === 'text' && (
          <div>
            <label htmlFor="text-input" className="block text-sm font-medium text-slate-300 mb-1">
              Paste text, an article link, or document content:
            </label>
            <textarea
              id="text-input"
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="e.g., 'The mitochondria is the powerhouse of the cell...' or 'https://example.com/article'"
              rows={8}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none text-slate-100 placeholder-slate-400"
              disabled={isLoading || !isApiKeySet}
            />
          </div>
        )}
        {activeInput === 'image' && (
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Upload an image (e.g., photo of a book page, screenshot, single PDF page as image):
            </label>
            <FileUpload 
              onFileSelect={(file, name) => { setFileInput(file); setFileName(name);}} 
              disabled={isLoading || !isApiKeySet} 
              acceptedFileTypes="image/jpeg, image/png, image/webp"
            />
            {fileName && <p className="text-sm text-slate-400 mt-2">Selected: {fileName}</p>}
          </div>
        )}
        {activeInput === 'video' && (
          <div>
            <label htmlFor="video-transcript-input" className="block text-sm font-medium text-slate-300 mb-1">
              Paste video transcript or a summary:
            </label>
            <textarea
              id="video-transcript-input"
              value={textInput} // Reusing textInput state for simplicity
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="e.g., 'In this video, we discuss the Krebs cycle...'"
              rows={8}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-inner focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none text-slate-100 placeholder-slate-400"
              disabled={isLoading || !isApiKeySet}
            />
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={isLoading || !isApiKeySet || (activeInput === 'image' && !fileInput) || (activeInput !== 'image' && !textInput.trim())}
          className="w-full bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-150 ease-in-out flex items-center justify-center text-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner /> : <><Lightbulb className="mr-2" /> Generate Flashcards</>}
        </button>
      </div>
       <p className="text-xs text-slate-400 mt-4 text-center">
        AI will analyze the content and create question/answer pairs. Results may vary based on input quality.
      </p>
    </div>
  );
};

export default CreateAutomaticView;
