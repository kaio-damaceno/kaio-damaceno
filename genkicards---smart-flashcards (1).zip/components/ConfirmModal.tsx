import React from 'react';
import { AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface ConfirmModalProps {
  title: string;
  message: string | React.ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
  confirmText?: string;
  cancelText?: string;
  confirmButtonClass?: string;
  iconType?: 'warning' | 'info' | 'success';
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
  title,
  message,
  onConfirm,
  onCancel,
  confirmText = "Confirmar",
  cancelText = "Cancelar",
  confirmButtonClass = "bg-green-500 hover:bg-green-600",
  iconType = "warning",
}) => {

  const Icon = () => {
    if (iconType === 'warning') return <AlertTriangle size={28} className="text-yellow-400 mr-3 flex-shrink-0" />;
    if (iconType === 'success') return <CheckCircle size={28} className="text-green-400 mr-3 flex-shrink-0" />;
    return <AlertTriangle size={28} className="text-sky-400 mr-3 flex-shrink-0" />; // Default to info-like
  };

  return (
    <div 
        className="fixed inset-0 bg-slate-900 bg-opacity-80 flex items-center justify-center z-50 p-4"
        onClick={onCancel} // Close on backdrop click
    >
      <div 
        className="bg-slate-800 p-6 rounded-lg shadow-xl w-full max-w-md animate-fadeIn"
        onClick={e => e.stopPropagation()} // Prevent backdrop click from closing if clicking inside modal
      >
        <div className="flex items-start mb-4">
            <Icon />
            <h2 className="text-xl font-semibold text-slate-100">{title}</h2>
        </div>
        
        <div className="text-slate-300 mb-6 text-sm">
            {typeof message === 'string' ? <p>{message}</p> : message}
        </div>

        <div className="flex justify-end space-x-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md transition-colors"
          >
            {cancelText}
          </button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 text-white rounded-md transition-colors ${confirmButtonClass}`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;