import React, { useState, useEffect } from 'react';
import { DeckNodeData } from '../types';
import { Save, XCircle } from 'lucide-react';

interface EditDeckModalProps {
  deckNode: DeckNodeData;
  onSave: (originalDeckPath: string, newFinalSegmentName: string) => void;
  onClose: () => void;
}

const EditDeckModal: React.FC<EditDeckModalProps> = ({ deckNode, onSave, onClose }) => {
  const [newDeckNameSegment, setNewDeckNameSegment] = useState(deckNode.name);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setNewDeckNameSegment(deckNode.name); // Reset when deckNode changes
    setError(null);
  }, [deckNode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeckNameSegment.trim()) {
      setError("Deck name cannot be empty.");
      return;
    }
    if (newDeckNameSegment.includes("::")) {
        setError("Deck name segment cannot contain '::'.");
        return;
    }
    setError(null);
    onSave(deckNode.fullPath, newDeckNameSegment.trim());
  };

  return (
    <div 
        className="fixed inset-0 bg-slate-900 bg-opacity-75 flex items-center justify-center z-50 p-4"
        onClick={onClose} // Close on backdrop click
    >
      <div 
        className="bg-slate-800 p-6 rounded-lg shadow-xl w-full max-w-md animate-fadeIn"
        onClick={e => e.stopPropagation()} // Prevent backdrop click from closing if clicking inside modal
    >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-sky-300">Renomear Baralho</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <XCircle size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="deckPathDisplay" className="block text-sm font-medium text-slate-400 mb-1">
              Caminho Completo Atual:
            </label>
            <input
              id="deckPathDisplay"
              type="text"
              value={deckNode.fullPath}
              readOnly
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-300 cursor-not-allowed"
            />
          </div>
          <div>
            <label htmlFor="deckNameSegment" className="block text-sm font-medium text-slate-300 mb-1">
              Novo Nome para "{deckNode.name}":
            </label>
            <input
              id="deckNameSegment"
              type="text"
              value={newDeckNameSegment}
              onChange={(e) => setNewDeckNameSegment(e.target.value)}
              className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-slate-100 focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              autoFocus
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-md transition-colors flex items-center"
            >
              <Save size={18} className="mr-2" /> Salvar Alterações
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDeckModal;