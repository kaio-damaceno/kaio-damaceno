
import React, { useState, useMemo, useRef, useCallback } from 'react';
import { AppView, Flashcard, GeneratedFlashcardPayload, InputType, DeckNodeData } from '../types';
import { PlusCircle, Mic, Brain, Upload, Edit3, Share, FolderPlus, Info, Download, CheckCircle } from 'lucide-react';
import { parseAnkiTxt } from '../services/importService';
import { buildDeckTree } from '../services/deckService'; 
import { exportFlashcardsToFile, parseFlashcardBackup } from '../services/storageService'; // Import from storageService
import LoadingSpinner from './LoadingSpinner';
import DeckTreeView from './DeckTreeView'; 
import ConfirmModal from './ConfirmModal'; 

interface HomeViewProps {
  setView: (view: AppView) => void;
  flashcards: Flashcard[];
  setFlashcards: (flashcards: Flashcard[]) => void; 
  addFlashcards: (cardsData: GeneratedFlashcardPayload[], sourceType: InputType, sourceInfo?: string) => void;
  setError: (error: string | null) => void;
  setIsLoading: (loading: boolean) => void;
  isLoading: boolean;
  handleStartReview: (deckPath: string | null) => void;
  handleViewDeckDetails: (deckPath: string) => void; 
  setDeckForEditing: (deck: DeckNodeData | null) => void; 
  setDeckForDeleting: (deck: DeckNodeData | null) => void; 
  handleOpenCreateDeckModal: (defaultParent?: string) => void; // Added prop
}

interface PendingImportData {
  file: File;
  data: Flashcard[];
}

const HomeView: React.FC<HomeViewProps> = ({ 
  setView, 
  flashcards,
  setFlashcards, 
  addFlashcards, 
  setError, 
  setIsLoading,
  isLoading,
  handleStartReview,
  handleViewDeckDetails,
  setDeckForEditing,
  setDeckForDeleting,
  handleOpenCreateDeckModal // Destructure prop
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [showImportConfirmModal, setShowImportConfirmModal] = useState(false);
  const [pendingImportData, setPendingImportData] = useState<PendingImportData | null>(null);


  const deckTreeData = useMemo(() => {
    if (flashcards && flashcards.length >= 0) { 
      return buildDeckTree(flashcards);
    }
    return [];
  }, [flashcards]);

  const clearMessages = () => {
    setError(null);
    setSuccessMessage(null);
  };

  const displaySuccess = (message: string) => {
    clearMessages();
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  const displayError = (message: string) => {
    clearMessages();
    setError(message);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleExportData = useCallback(() => {
    clearMessages();
    setIsLoading(true);
    try {
      exportFlashcardsToFile(flashcards); // Use storageService
      displaySuccess("Backup exportado com sucesso!");
    } catch (err) {
      console.error("Export error:", err);
      displayError((err as Error).message || "Ocorreu um erro durante o backup.");
    } finally {
      setIsLoading(false);
    }
  }, [flashcards, setIsLoading]);


  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    clearMessages();
    setIsImporting(true);
    setIsLoading(true);

    try {
      const fileContent = await file.text();
      if (file.name.endsWith('.json')) {
        const importedData = parseFlashcardBackup(fileContent); // Use storageService
        if (importedData) {
          setPendingImportData({ file, data: importedData });
          setShowImportConfirmModal(true);
        } else {
          displayError("Arquivo JSON de backup inválido. Verifique o formato e tente novamente.");
        }
      } else if (file.name.endsWith('.txt')) {
        const importedCards = await parseAnkiTxt(fileContent);
        if (importedCards.length > 0) {
          addFlashcards(importedCards, InputType.ANKI_IMPORT, file.name);
          displaySuccess(`Arquivo Anki TXT "${file.name}" importado. ${importedCards.length} cards adicionados.`);
        } else {
          displayError("Nenhum flashcard válido encontrado no arquivo TXT.");
        }
      } else {
        displayError("Tipo de arquivo não suportado. Use .txt para Anki ou .json para backup GenkiCards.");
      }
    } catch (err) {
      console.error("Import error:", err);
      displayError(`Erro ao importar arquivo: ${(err as Error).message}`);
    } finally {
      setIsImporting(false);
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = ""; 
      }
    }
  };

  const handleConfirmImport = () => {
    if (pendingImportData) {
      setFlashcards(pendingImportData.data);
      displaySuccess(`Backup "${pendingImportData.file.name}" importado com sucesso! Seus dados foram substituídos.`);
      setPendingImportData(null);
      setShowImportConfirmModal(false);
    }
  };
  
  const handleGetShared = () => {
    alert("Obter Baralhos Compartilhados: Esta funcionalidade está planejada para uma atualização futura!");
  };

  const totalDueForAllDecks = useMemo(() => {
    if (!deckTreeData || deckTreeData.length === 0) return 0;
    return deckTreeData.reduce((sum, deckNode) => 
        sum + deckNode.stats.newCardsDue + deckNode.stats.learningCardsDue + deckNode.stats.reviewCardsDue, 
    0);
  }, [deckTreeData]);


  return (
    <div className="space-y-6 animate-fadeIn">
       {successMessage && (
        <div className="bg-green-500 border border-green-600 text-white px-4 py-3 rounded-lg relative mb-4 flex items-center shadow-lg" role="alert">
          <CheckCircle className="h-5 w-5 mr-2" />
          <span className="block sm:inline">{successMessage}</span>
          <button onClick={() => setSuccessMessage(null)} className="absolute top-1 right-1 text-green-100 hover:text-white">
            <Info size={14}/> 
          </button>
        </div>
      )}

      <section className="flex flex-col sm:flex-row flex-wrap justify-center items-center gap-3 md:gap-4 py-4 border-b border-slate-700">
        <button
          onClick={() => setView(AppView.CREATE_AUTOMATIC)}
          className="w-full sm:w-auto bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center justify-center transform hover:scale-105"
        >
          <PlusCircle size={18} className="mr-2" /> Auto Criar
        </button>
         <button
          onClick={() => setView(AppView.CREATE_MANUAL)}
          className="w-full sm:w-auto bg-teal-500 hover:bg-teal-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center justify-center transform hover:scale-105"
        >
          <Edit3 size={18} className="mr-2" /> Criar Manual
        </button>
        <button
          onClick={() => setView(AppView.VOICE_MODE)}
          className="w-full sm:w-auto bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center justify-center transform hover:scale-105"
        >
          <Mic size={18} className="mr-2" /> Modo Voz
        </button>
        <button
          onClick={() => handleStartReview(null)} 
          disabled={totalDueForAllDecks === 0 && flashcards.length === 0}
          className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md flex items-center justify-center transform hover:scale-105 disabled:opacity-50"
        >
          <Brain size={18} className="mr-2" /> Revisar Tudo ({totalDueForAllDecks > 0 ? totalDueForAllDecks : (flashcards.length > 0 ? 'Aprender' : '0')})
        </button>
      </section>
      
      <section className="bg-slate-800 p-1 sm:p-2 md:p-4 rounded-xl shadow-xl">
        {flashcards.length === 0 && deckTreeData.length === 0 ? ( 
            <div className="text-center py-10">
                <Info size={48} className="mx-auto text-sky-400 mb-4" />
                <p className="text-slate-300 text-lg mb-2">Nenhum baralho para mostrar.</p>
                <p className="text-slate-400">Crie alguns flashcards ou importe um baralho para começar!</p>
            </div>
        ) : deckTreeData.length === 0 && flashcards.length > 0 ? ( 
            <div className="text-center py-10">
                <LoadingSpinner text="Organizando baralhos..." />
            </div>
        ) : (
             <DeckTreeView 
                deckTree={deckTreeData} 
                onReviewDeck={handleStartReview} 
                onViewDeckDetails={handleViewDeckDetails}
                onEditDeck={setDeckForEditing}
                onDeleteDeck={setDeckForDeleting}
                onOpenCreateDeckModal={handleOpenCreateDeckModal} // Pass handler
            />
        )}
      </section>

      <section className="mt-6 flex flex-col sm:flex-row flex-wrap justify-center items-center gap-3 md:gap-4 pt-4 border-t border-slate-700">
        <button
            onClick={handleGetShared}
            className="w-full sm:w-auto bg-slate-600 hover:bg-slate-500 text-slate-200 font-medium py-2 px-4 rounded-lg shadow flex items-center justify-center"
        >
            <Share size={18} className="mr-2"/> Obter Compartilhados
        </button>
        <button
            onClick={() => handleOpenCreateDeckModal()} // Updated onClick
            className="w-full sm:w-auto bg-slate-600 hover:bg-slate-500 text-slate-200 font-medium py-2 px-4 rounded-lg shadow flex items-center justify-center"
        >
            <FolderPlus size={18} className="mr-2"/> Criar Baralho
        </button>
        <button
          onClick={handleImportClick}
          disabled={isImporting}
          className="w-full sm:w-auto bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-lg shadow flex items-center justify-center disabled:opacity-50"
        >
          {isImporting ? <LoadingSpinner size="sm" /> : <><Upload size={18} className="mr-2" /> Importar Arquivo</>}
        </button>
        <input type="file" ref={fileInputRef} onChange={handleFileImport} accept=".txt,.json" style={{ display: 'none' }} />
         <button
          onClick={handleExportData}
          disabled={isLoading || flashcards.length === 0}
          className="w-full sm:w-auto bg-cyan-600 hover:bg-cyan-700 text-white font-semibold py-2 px-4 rounded-lg shadow flex items-center justify-center disabled:opacity-50"
        >
          <Download size={18} className="mr-2" /> Exportar Backup
        </button>
      </section>

      {showImportConfirmModal && pendingImportData && (
        <ConfirmModal
          title="Confirmar Importação de Backup"
          message={
            <>
              <p>Tem certeza que deseja importar o arquivo "<strong>{pendingImportData.file.name}</strong>"?</p>
              <p className="font-semibold text-yellow-400 mt-2">Todos os seus flashcards e baralhos atuais serão substituídos por este backup.</p>
              <p className="mt-1">Esta ação não pode ser desfeita.</p>
            </>
          }
          onConfirm={handleConfirmImport}
          onCancel={() => {
            setShowImportConfirmModal(false);
            setPendingImportData(null);
          }}
          confirmText="Sim, Substituir Tudo"
          cancelText="Cancelar"
          confirmButtonClass="bg-yellow-500 hover:bg-yellow-600"
          iconType="warning"
        />
      )}
    </div>
  );
};

export default HomeView;
