
import React from 'react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  textColor?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ size = 'md', text, textColor = 'text-slate-200' }) => {
  const sizeClasses = {
    sm: 'w-6 h-6 border-2',
    md: 'w-8 h-8 border-[3px]',
    lg: 'w-12 h-12 border-4',
  };

  return (
    <div className="flex flex-col items-center justify-center" aria-live="polite" aria-busy="true">
      <div
        className={`animate-spin rounded-full border-sky-500 border-t-transparent ${sizeClasses[size]}`}
        role="status"
      >
        <span className="sr-only">Loading...</span>
      </div>
      {text && <p className={`mt-2 text-sm ${textColor}`}>{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
