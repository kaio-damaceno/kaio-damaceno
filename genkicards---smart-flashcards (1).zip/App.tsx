
// Fix: Import 'useMemo' from 'react'
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Flashcard, AppView, InputType, ApiKeyCheckerProps, GeneratedFlashcardPayload, DeckNodeData, CardState, ReviewQuality } from './types';
import { v4 as uuidv4 } from 'uuid';
import Header from './components/Header';
import CreateAutomaticView from './components/CreateAutomaticView';
import CreateManualView from './components/CreateManualView';
import VoiceModeView from './components/VoiceModeView';
import ReviewSession from './components/ReviewSession';
import HomeView from './components/HomeView';
import DeckDetailView from './components/DeckDetailView';
import EditDeckModal from './components/EditDeckModal';
import EditFlashcardModal from './components/EditFlashcardModal';
import ConfirmModal from './components/ConfirmModal';
import CreateDeckModal from './components/CreateDeckModal'; // Import new modal
import { 
  MOCK_API_KEY_WARNING, 
  MAX_DAILY_REVIEW_LIMIT, 
  LEARNING_STABILITY_THRESHOLD_DAYS,
  INITIAL_STABILITY,
  INITIAL_DIFFICULTY_EASY,
  INITIAL_DIFFICULTY_MEDIUM,
  INITIAL_DIFFICULTY_HARD
} from './constants';
import { getCardState } from './services/deckService';
import { calculateRetrievability, calculateUrgency } from './services/ultraMemoService'; 
import { loadFlashcards, saveFlashcards } from './services/storageService'; // Import from storageService
import { AlertTriangle } from 'lucide-react';

const ApiKeyChecker: React.FC<ApiKeyCheckerProps> = ({ isApiKeySet }) => {
  if (isApiKeySet) {
    return null;
  }
  return (
    <div className="bg-yellow-500 border-l-4 border-yellow-700 text-yellow-900 p-4 mb-6 rounded-md shadow-lg flex items-center" role="alert">
      <AlertTriangle className="h-6 w-6 mr-3 text-yellow-700" />
      <div>
        <p className="font-bold">API Key Not Found</p>
        <p>{MOCK_API_KEY_WARNING}</p>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [flashcards, setFlashcards] = useState<Flashcard[]>(() => {
    return loadFlashcards(); // Use storageService to load cards
  });
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isApiKeySet, setIsApiKeySet] = useState<boolean>(false);
  
  const [reviewFilterPath, setReviewFilterPath] = useState<string | null>(null);
  const [currentReviewBatch, setCurrentReviewBatch] = useState<Flashcard[]>([]);
  const [viewingDeckPath, setViewingDeckPath] = useState<string | null>(null);

  const [deckForEditing, setDeckForEditing] = useState<DeckNodeData | null>(null);
  const [deckForDeleting, setDeckForDeleting] = useState<DeckNodeData | null>(null);
  const [flashcardForEditing, setFlashcardForEditing] = useState<Flashcard | null>(null);
  const [flashcardIdForDeleting, setFlashcardIdForDeleting] = useState<string | null>(null);

  // State for CreateDeckModal
  const [showCreateDeckModal, setShowCreateDeckModal] = useState(false);
  const [defaultParentPathForCreateDeckModal, setDefaultParentPathForCreateDeckModal] = useState<string | null>(null);
  const [pendingDeckPathForManualCard, setPendingDeckPathForManualCard] = useState<string | null>(null);


  useEffect(() => {
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
       setIsApiKeySet(true);
    } else {
      setIsApiKeySet(false); 
    }
  }, []);

  useEffect(() => {
    saveFlashcards(flashcards); // Use storageService to save cards
  }, [flashcards]);

  const addFlashcards = useCallback((newCardsData: GeneratedFlashcardPayload[], sourceType: InputType, sourceInfo?: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const now = new Date();
      const todayISO = now.toISOString().split('T')[0];

      const newFlashcardsToAdd: Flashcard[] = newCardsData.map(cardData => {
        let initialDifficultyValue: number;
        switch (cardData.dificuldade?.toLowerCase()) {
          case 'fácil':
          case 'easy':
            initialDifficultyValue = INITIAL_DIFFICULTY_EASY;
            break;
          case 'média':
          case 'medium':
            initialDifficultyValue = INITIAL_DIFFICULTY_MEDIUM;
            break;
          case 'difícil':
          case 'hard':
            initialDifficultyValue = INITIAL_DIFFICULTY_HARD;
            break;
          default:
            initialDifficultyValue = INITIAL_DIFFICULTY_MEDIUM;
        }

        return {
          id: uuidv4(),
          pergunta: cardData.pergunta,
          resposta: cardData.resposta,
          
          stability: INITIAL_STABILITY,
          difficulty: initialDifficultyValue,
          lastReviewedTimestamp: undefined, 
          consecutiveCorrectAnswers: 0,
          initialDifficultyEstimate: cardData.dificuldade,
          lastResponseTimeSeconds: undefined,

          nextReviewDate: todayISO, 
          lastReviewedDate: undefined,
          sourceType,
          sourceInfo,
          tags: cardData.tags || [],
          deckPath: cardData.deckPath?.trim() || 'Default',
          htmlContent: cardData.htmlContent || false,
        };
      });
      setFlashcards(prev => [...prev, ...newFlashcardsToAdd]);
      
      if (sourceType === InputType.MANUAL) {
        // Manual view handles its own state reset, but if it was triggered by new deck flow, go home.
        if (pendingDeckPathForManualCard) {
            setCurrentView(AppView.HOME);
            setPendingDeckPathForManualCard(null); // Clear after use
        }
      } else { 
         setCurrentView(AppView.HOME); 
      }
    } catch (e) {
      console.error("Error adding flashcards:", e);
      setError("Failed to process and add new flashcards.");
    } finally {
      setIsLoading(false);
    }
  }, [pendingDeckPathForManualCard]);

  const handleUpdateFlashcard = useCallback((updatedCard: Flashcard) => {
    setFlashcards(prevFlashcards =>
        prevFlashcards.map(card => card.id === updatedCard.id ? updatedCard : card)
    );
    setCurrentReviewBatch(prevBatch => {
        if (!prevBatch || !Array.isArray(prevBatch)) return [];
        return prevBatch.filter(card => card.id !== updatedCard.id);
    });
    setFlashcardForEditing(null); 
  }, []);
  
  const handleDeleteFlashcard = useCallback((cardId: string) => {
    setFlashcards(prev => prev.filter(card => card.id !== cardId));
    setCurrentReviewBatch(prevBatch => {
        if (!prevBatch || !Array.isArray(prevBatch)) return [];
        return prevBatch.filter(card => card.id !== cardId);
    });
    setFlashcardIdForDeleting(null);
  }, []);

  const handleRenameDeck = useCallback((originalDeckPath: string, newFinalSegmentName: string) => {
    if (!originalDeckPath || !newFinalSegmentName || !newFinalSegmentName.trim()) {
        setError("Invalid deck name provided for rename.");
        return;
    }
    
    const pathSegments = originalDeckPath.split('::');
    let newDeckPathPrefix: string;

    if (pathSegments.length === 1) {
        newDeckPathPrefix = newFinalSegmentName;
    } else {
        const parentPath = pathSegments.slice(0, -1).join('::');
        newDeckPathPrefix = `${parentPath}::${newFinalSegmentName}`;
    }

    if (newDeckPathPrefix === originalDeckPath) {
        setDeckForEditing(null);
        return;
    }
    
    setFlashcards(prevFlashcards => 
        prevFlashcards.map(card => {
            if (card.deckPath === originalDeckPath) {
                return { ...card, deckPath: newDeckPathPrefix };
            }
            if (card.deckPath?.startsWith(originalDeckPath + "::")) {
                const subPath = card.deckPath.substring((originalDeckPath + "::").length);
                return { ...card, deckPath: `${newDeckPathPrefix}::${subPath}` };
            }
            return card;
        })
    );
    setDeckForEditing(null);
    if (viewingDeckPath === originalDeckPath) setViewingDeckPath(newDeckPathPrefix);
    if (reviewFilterPath === originalDeckPath) setReviewFilterPath(newDeckPathPrefix);

  }, [viewingDeckPath, reviewFilterPath]); 

  const handleDeleteDeckConfirmed = useCallback(() => {
    if (!deckForDeleting) return;
    const pathToDelete = deckForDeleting.fullPath;
    setFlashcards(prevFlashcards => 
        prevFlashcards.filter(card => 
            !(card.deckPath === pathToDelete || card.deckPath?.startsWith(pathToDelete + "::"))
        )
    );
    setDeckForDeleting(null);
    if (viewingDeckPath?.startsWith(pathToDelete)) setViewingDeckPath(null); 
    if (reviewFilterPath?.startsWith(pathToDelete)) setReviewFilterPath(null);
    setCurrentReviewBatch(prevBatch => 
        prevBatch.filter(card => 
            !(card.deckPath === pathToDelete || card.deckPath?.startsWith(pathToDelete + "::"))
        )
    );
  }, [deckForDeleting, viewingDeckPath, reviewFilterPath]);


  const handleStartReview = useCallback((deckPath: string | null) => {
    const todayEpoch = new Date().setHours(0,0,0,0); 
    const todayISO = new Date(todayEpoch).toISOString().split('T')[0];
    
    let V_filteredByDeckPath = flashcards;
    if (deckPath) {
      V_filteredByDeckPath = flashcards.filter(card => 
        card.deckPath && (card.deckPath === deckPath || card.deckPath.startsWith(deckPath + "::"))
      );
    }

    const V_dueCardsFromFilter = V_filteredByDeckPath
      .filter(card => getCardState(card, todayISO, LEARNING_STABILITY_THRESHOLD_DAYS) !== CardState.NOT_DUE)
      .map(card => {
        const t = card.lastReviewedTimestamp 
                    ? (todayEpoch - new Date(new Date(card.lastReviewedTimestamp).setHours(0,0,0,0)).getTime()) / (1000 * 60 * 60 * 24)
                    : 0; 
        const R = calculateRetrievability(t, card.stability);
        const U = calculateUrgency(R, card.difficulty); 
        return { cardRef: card, urgency: U, nextReviewDate: card.nextReviewDate, consecutiveCorrectAnswers: card.consecutiveCorrectAnswers };
      })
      .sort((a, b) => { 
        if ((b.urgency ?? 0) !== (a.urgency ?? 0)) return (b.urgency ?? 0) - (a.urgency ?? 0);
        const dateA = new Date(a.nextReviewDate).getTime();
        const dateB = new Date(b.nextReviewDate).getTime();
        if (dateA !== dateB) return dateA - dateB;
        return a.consecutiveCorrectAnswers - b.consecutiveCorrectAnswers;
      })
      .map(item => item.cardRef); 
    
    let V_batchForSession: Flashcard[];
    if (V_dueCardsFromFilter.length > MAX_DAILY_REVIEW_LIMIT) {
      V_batchForSession = V_dueCardsFromFilter.slice(0, MAX_DAILY_REVIEW_LIMIT);
    } else {
      V_batchForSession = V_dueCardsFromFilter;
    }
    
    if (V_batchForSession.length === 0 && V_filteredByDeckPath.length > 0) {
      const learnSomeSource = deckPath ? V_filteredByDeckPath : flashcards; 
      V_batchForSession = [...learnSomeSource] 
        .filter(card => { 
            const state = getCardState(card, todayISO, LEARNING_STABILITY_THRESHOLD_DAYS);
            return state === CardState.NEW || state === CardState.LEARNING || card.stability < 5; 
        })
        .sort((a, b) => { 
            if(a.stability !== b.stability) return a.stability - b.stability; 
            const tsA = a.lastReviewedTimestamp ?? Number.MAX_SAFE_INTEGER; 
            const tsB = b.lastReviewedTimestamp ?? Number.MAX_SAFE_INTEGER;
            return tsB - tsA; 
        })
        .slice(0, Math.min(MAX_DAILY_REVIEW_LIMIT, learnSomeSource.length, 20)); 
    }
    
    setCurrentReviewBatch(V_batchForSession);
    setReviewFilterPath(deckPath);
    setCurrentView(AppView.REVIEW);
  }, [flashcards]);
  
  const handleViewDeckDetails = useCallback((deckPath: string) => {
    setViewingDeckPath(deckPath);
    setCurrentView(AppView.DECK_DETAIL);
  }, []);

  const uniqueDeckPaths = useMemo(() => {
    const paths = new Set<string>();
    flashcards.forEach(card => {
      if (card.deckPath) {
        const segments = card.deckPath.split("::");
        for (let i = 0; i < segments.length; i++) {
          paths.add(segments.slice(0, i + 1).join("::"));
        }
      }
    });
    return Array.from(paths).sort();
  }, [flashcards]);

  // Create Deck Modal Handlers
  const handleOpenCreateDeckModal = useCallback((defaultParent?: string) => {
    setDefaultParentPathForCreateDeckModal(defaultParent || null);
    setShowCreateDeckModal(true);
  }, []);

  const handleCloseCreateDeckModal = useCallback(() => {
    setShowCreateDeckModal(false);
    setDefaultParentPathForCreateDeckModal(null);
  }, []);

  const handleConfirmCreateDeck = useCallback((fullNewDeckPath: string) => {
    setPendingDeckPathForManualCard(fullNewDeckPath);
    setCurrentView(AppView.CREATE_MANUAL);
    handleCloseCreateDeckModal();
  }, [handleCloseCreateDeckModal]);


  const renderView = () => {
    switch (currentView) {
      case AppView.HOME:
        return <HomeView 
                  setView={setCurrentView} 
                  flashcards={flashcards} 
                  setFlashcards={setFlashcards} 
                  addFlashcards={addFlashcards} 
                  setError={setError} 
                  setIsLoading={setIsLoading}
                  isLoading={isLoading}
                  handleStartReview={handleStartReview} 
                  handleViewDeckDetails={handleViewDeckDetails}
                  setDeckForEditing={setDeckForEditing}
                  setDeckForDeleting={setDeckForDeleting}
                  handleOpenCreateDeckModal={handleOpenCreateDeckModal} // Pass handler
                />;
      case AppView.CREATE_AUTOMATIC:
        return <CreateAutomaticView addFlashcards={addFlashcards} isLoading={isLoading} setIsLoading={setIsLoading} setError={setError} isApiKeySet={isApiKeySet} />;
      case AppView.CREATE_MANUAL: 
        return <CreateManualView 
                  addFlashcards={addFlashcards} 
                  setIsLoading={setIsLoading} 
                  setError={setError} 
                  existingDeckPaths={uniqueDeckPaths}
                  initialDeckPath={pendingDeckPathForManualCard} // Pass pending path
                  onInitialDeckPathConsumed={() => setPendingDeckPathForManualCard(null)} // Pass handler to clear
               />;
      case AppView.VOICE_MODE:
        return <VoiceModeView addFlashcards={addFlashcards} isLoading={isLoading} setIsLoading={setIsLoading} error={error} setError={setError} isApiKeySet={isApiKeySet} />;
      case AppView.REVIEW:
        return <ReviewSession 
                  initialBatch={currentReviewBatch}
                  allFlashcards={flashcards} 
                  onUpdateFlashcard={handleUpdateFlashcard} 
                  setView={setCurrentView} 
                  reviewFilterPath={reviewFilterPath}
                  setReviewFilterPath={setReviewFilterPath} 
                />;
      case AppView.DECK_DETAIL:
        if (!viewingDeckPath) {
          setCurrentView(AppView.HOME); 
          return null;
        }
        return <DeckDetailView
                  deckPath={viewingDeckPath}
                  allFlashcards={flashcards}
                  onEditFlashcardRequest={(card) => setFlashcardForEditing(card)}
                  onDeleteFlashcardRequest={(cardId) => setFlashcardIdForDeleting(cardId)}
                  setView={setCurrentView}
                  uniqueDeckPaths={uniqueDeckPaths}
                  handleStartReview={handleStartReview}
                />;
      default:
        return <HomeView 
                  setView={setCurrentView} 
                  flashcards={flashcards} 
                  setFlashcards={setFlashcards} 
                  addFlashcards={addFlashcards} 
                  setError={setError} 
                  setIsLoading={setIsLoading}
                  isLoading={isLoading}
                  handleStartReview={handleStartReview}
                  handleViewDeckDetails={handleViewDeckDetails}
                  setDeckForEditing={setDeckForEditing}
                  setDeckForDeleting={setDeckForDeleting}
                  handleOpenCreateDeckModal={handleOpenCreateDeckModal} // Pass handler
                />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 flex flex-col items-center p-4 md:p-8">
      <Header currentView={currentView} setView={setCurrentView} />
      <main className="w-full max-w-4xl mt-8">
        <ApiKeyChecker isApiKeySet={isApiKeySet} />
        {error && (
          <div className="bg-red-500 text-white p-3 rounded-md mb-4 animate-shake" role="alert">
            <p className="font-semibold">Error:</p>
            <p>{error}</p>
            <button onClick={() => setError(null)} className="text-sm underline mt-1">Dismiss</button>
          </div>
        )}
        {renderView()}

        {deckForEditing && (
            <EditDeckModal 
                deckNode={deckForEditing}
                onSave={handleRenameDeck}
                onClose={() => setDeckForEditing(null)}
            />
        )}
        {deckForDeleting && (
            <ConfirmModal
                title={`Excluir Baralho: ${deckForDeleting.name}`}
                message={<>Tem certeza que deseja excluir o baralho "<strong>{deckForDeleting.fullPath}</strong>" e todos os seus flashcards? Esta ação não pode ser desfeita.</>}
                onConfirm={handleDeleteDeckConfirmed}
                onCancel={() => setDeckForDeleting(null)}
                confirmText="Excluir Baralho"
                confirmButtonClass="bg-red-600 hover:bg-red-700"
            />
        )}
        {flashcardForEditing && (
            <EditFlashcardModal
                flashcardToEdit={flashcardForEditing}
                onSaveFlashcard={handleUpdateFlashcard}
                onCancel={() => setFlashcardForEditing(null)}
                uniqueDeckPaths={uniqueDeckPaths}
            />
        )}
        {flashcardIdForDeleting && (
            <ConfirmModal
                title="Excluir Flashcard"
                message="Tem certeza que deseja excluir este flashcard? Esta ação não pode ser desfeita."
                onConfirm={() => handleDeleteFlashcard(flashcardIdForDeleting)}
                onCancel={() => setFlashcardIdForDeleting(null)}
                confirmText="Excluir Flashcard"
                confirmButtonClass="bg-red-600 hover:bg-red-700"
            />
        )}

        {showCreateDeckModal && (
          <CreateDeckModal
            isOpen={showCreateDeckModal}
            onClose={handleCloseCreateDeckModal}
            onConfirmCreateDeck={handleConfirmCreateDeck}
            existingDeckPaths={uniqueDeckPaths}
            defaultParentPath={defaultParentPathForCreateDeckModal}
          />
        )}

      </main>
      <footer className="w-full max-w-4xl mt-12 text-center text-slate-400 text-sm">
        <p>&copy; {new Date().getFullYear()} GenkiCards. Powered by AI.</p>
      </footer>
    </div>
  );
};

export default App;
