
import { Flashcard, ReviewQuality } from '../types';
import {
  INITIAL_STABILITY,
  MIN_STABILITY,
  MAX_STABILITY,
  MIN_DIFFICULTY,
  MAX_DIFFICULTY,
  T_MAX_RESPONSE_TIME_SECONDS,
  A_MAX_CONSECUTIVE_CORRECT,
  USER_DIFFICULTY_WEIGHT_ALPHA,
  D_USER_PERFECT,
  D_USER_HESITATION,
  D_USER_CORRECT_HARD,
  D_USER_INCORRECT_EASY,
  D_USER_INCORRECT_HARD,
} from '../constants';

/**
 * Calculates Retrievability (R)
 * R = e^(-t/S)
 * @param t Time in days since last review
 * @param S Stability in days
 */
export const calculateRetrievability = (t: number, S: number): number => {
  if (S <= 0) return 0; // Avoid division by zero or invalid stability
  return Math.exp(-t / S);
};

/**
 * Calculates Urgency (U)
 * U = (1 - R) * D * Peso_ML
 * @param R Retrievability
 * @param D Difficulty
 * @param pesoML Machine Learning weight (default to 1 for now)
 */
export const calculateUrgency = (R: number, D: number, pesoML: number = 1): number => {
  return (1 - R) * D * pesoML;
};

const mapReviewQualityToUserDifficulty = (quality: ReviewQuality): number => {
  switch (quality) {
    case ReviewQuality.Perfect:
      return D_USER_PERFECT;
    case ReviewQuality.CorrectHesitation:
      return D_USER_HESITATION;
    case ReviewQuality.CorrectHard:
      return D_USER_CORRECT_HARD;
    case ReviewQuality.IncorrectEasy: // Incorrect, but perceived as easy by user
      return D_USER_INCORRECT_EASY;
    case ReviewQuality.IncorrectHard: // Incorrect, perceived as hard
      return D_USER_INCORRECT_HARD;
    case ReviewQuality.Blackout: // Complete failure
      return D_USER_INCORRECT_HARD; // Treat as very difficult
    default:
      return D_USER_HESITATION; // Default to medium if quality is somehow undefined
  }
};

export const updateCardUltraMemo = (
  card: Flashcard,
  quality: ReviewQuality,
  responseTimeSeconds: number,
): Flashcard => {
  const isCorrect = quality >= ReviewQuality.CorrectHard;
  const D_current = card.difficulty;
  const S_current = card.stability;
  let A_current = card.consecutiveCorrectAnswers;
  const T = Math.min(responseTimeSeconds, T_MAX_RESPONSE_TIME_SECONDS); // Cap response time

  // 1. Update Consecutive Correct Answers (A)
  if (isCorrect) {
    A_current = Math.min(A_current + 1, A_MAX_CONSECUTIVE_CORRECT);
  } else {
    A_current = 0; // Reset on error
  }

  // 2. Calculate ΔD (Delta Difficulty)
  // ΔD = T/T_max - A/A_max (H/H_max is ignored for now)
  // Note: A_current here is the value *before* this review for the formula,
  // but the prompt's example implies using current performance.
  // Let's use A_current *after* update (reflecting current success streak ending at this card if correct, or 0 if incorrect)
  // For "A: Acertos consecutivos (0 a 5)", A_current is the state *after* this review.
  // The example ΔD = T/Tmax - A/Amax implies A is based on history *up to this review*.
  // Let's use card.consecutiveCorrectAnswers for the historic A for ΔD calculation, then update it.
  const A_for_delta_D = card.consecutiveCorrectAnswers; // A before this review
  const delta_D = (T / T_MAX_RESPONSE_TIME_SECONDS) - (A_for_delta_D / A_MAX_CONSECUTIVE_CORRECT);

  // 3. Update Difficulty (D)
  // D_novo = α ⋅ D_user + (1 − α) ⋅ (D_algo + ΔD)
  // D_algo here is D_current (difficulty before this review)
  const D_user_input = mapReviewQualityToUserDifficulty(quality);
  let new_D = USER_DIFFICULTY_WEIGHT_ALPHA * D_user_input +
              (1 - USER_DIFFICULTY_WEIGHT_ALPHA) * (D_current + delta_D);
  new_D = Math.max(MIN_DIFFICULTY, Math.min(MAX_DIFFICULTY, new_D)); // Clamp D

  // 4. Update Stability (S)
  let new_S: number;
  if (isCorrect) {
    // S_novo = S × (1 + (1 − D_new) × (1 − T/T_max))
    new_S = S_current * (1 + (1 - new_D) * (1 - T / T_MAX_RESPONSE_TIME_SECONDS));
    new_S = Math.max(MIN_STABILITY, Math.min(MAX_STABILITY, new_S));
    // Ensure stability increases meaningfully for correct answers, especially from low S
    if (new_S <= S_current && S_current < MAX_STABILITY) {
        new_S = S_current * (1.2 + (1-new_D)*0.5); // Simplified growth factor
    }

  } else {
    // S_novo = max(1, S × 0.5)
    new_S = Math.max(INITIAL_STABILITY, S_current * 0.5); // User prompt says max(1, S*0.5) initial S is 1.
  }
  new_S = Math.max(MIN_STABILITY, Math.min(MAX_STABILITY, new_S)); // Clamp S

  // 5. Update Dates
  const today = new Date();
  const lastReviewedDateISO = today.toISOString().split('T')[0];
  const lastReviewedTimestamp = today.getTime();

  const nextReview = new Date(today);
  nextReview.setDate(today.getDate() + Math.round(new_S)); // Add stability (in days)
  const nextReviewDateISO = nextReview.toISOString().split('T')[0];

  return {
    ...card,
    stability: parseFloat(new_S.toFixed(2)),
    difficulty: parseFloat(new_D.toFixed(2)),
    consecutiveCorrectAnswers: A_current,
    lastReviewedDate: lastReviewedDateISO,
    lastReviewedTimestamp: lastReviewedTimestamp,
    nextReviewDate: nextReviewDateISO,
    lastResponseTimeSeconds: responseTimeSeconds,
  };
};
