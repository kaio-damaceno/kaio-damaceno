
import { Flashcard, DeckNodeData, DeckStats, CardState } from '../types';
import { LEARNING_STABILITY_THRESHOLD_DAYS } from '../constants'; // Updated constant name

export const getCardState = (card: Flashcard, today: string, learningThresholdDays: number): CardState => {
  if (card.nextReviewDate > today) {
    return CardState.NOT_DUE;
  }
  // A card is new if it hasn't been reviewed, or its lastReviewedDate is undefined.
  // consecutiveCorrectAnswers being 0 and no last review also indicates new.
  if (!card.lastReviewedDate && card.consecutiveCorrectAnswers === 0) {
    return CardState.NEW;
  }
  // If due and stability is below threshold, it's learning.
  if (card.stability < learningThresholdDays) {
    return CardState.LEARNING;
  }
  // Otherwise, it's a review card.
  return CardState.REVIEW;
};

interface DeckStatsInternal extends DeckStats {
  _directNew: number;
  _directLearning: number;
  _directReview: number;
  _directTotal: number;
  _directMastered: number; 
}

interface DeckNodeDataInternal extends Omit<DeckNodeData, 'stats' | 'children'> {
    stats: DeckStatsInternal;
    children: DeckNodeDataInternal[];
}


export const buildDeckTree = (flashcards: Flashcard[]): DeckNodeData[] => {
  const today = new Date().toISOString().split('T')[0];
  const root: DeckNodeDataInternal = {
    name: 'ROOT', 
    fullPath: 'ROOT',
    children: [],
    stats: { 
      newCardsDue: 0, learningCardsDue: 0, reviewCardsDue: 0, totalCardsInHierarchy: 0,
      masteredCards: 0, progressPercent: 0,
      _directNew: 0, _directLearning: 0, _directReview: 0, _directTotal: 0, _directMastered: 0,
    },
  };

  const findOrCreateNode = (pathSegments: string[], parentNode: DeckNodeDataInternal): DeckNodeDataInternal => {
    if (pathSegments.length === 0) {
      return parentNode;
    }

    const segmentName = pathSegments[0];
    const currentFullPath = parentNode.fullPath === 'ROOT' ? segmentName : `${parentNode.fullPath}::${segmentName}`;
    
    let childNode = parentNode.children.find(child => child.name === segmentName);

    if (!childNode) {
      childNode = {
        name: segmentName,
        fullPath: currentFullPath,
        children: [],
        stats: {
            newCardsDue: 0, learningCardsDue: 0, reviewCardsDue: 0, totalCardsInHierarchy: 0,
            masteredCards: 0, progressPercent: 0,
            _directNew: 0, _directLearning: 0, _directReview: 0, _directTotal: 0, _directMastered: 0,
        },
      };
      parentNode.children.push(childNode);
    }
    return findOrCreateNode(pathSegments.slice(1), childNode);
  };

  flashcards.forEach(card => {
    const deckPath = card.deckPath || 'Default';
    const pathSegments = deckPath.split('::');
    const node = findOrCreateNode(pathSegments, root);
    const nodeStats = node.stats;

    nodeStats._directTotal++;
    // A card is mastered if its stability is at or above the learning threshold
    if (card.stability >= LEARNING_STABILITY_THRESHOLD_DAYS) {
      nodeStats._directMastered++;
    }

    const cardStatus = getCardState(card, today, LEARNING_STABILITY_THRESHOLD_DAYS);
    if (cardStatus === CardState.NEW) nodeStats._directNew++;
    else if (cardStatus === CardState.LEARNING) nodeStats._directLearning++;
    else if (cardStatus === CardState.REVIEW) nodeStats._directReview++;
  });

  const calculateCumulativeStats = (node: DeckNodeDataInternal): DeckStats => {
    const nodeStats = node.stats;
    let cumulativeNew = nodeStats._directNew;
    let cumulativeLearning = nodeStats._directLearning;
    let cumulativeReview = nodeStats._directReview;
    let cumulativeTotal = nodeStats._directTotal;
    let cumulativeMastered = nodeStats._directMastered;

    node.children.forEach(child => {
      const childCumulativeStats = calculateCumulativeStats(child);
      cumulativeNew += childCumulativeStats.newCardsDue;
      cumulativeLearning += childCumulativeStats.learningCardsDue;
      cumulativeReview += childCumulativeStats.reviewCardsDue;
      cumulativeTotal += childCumulativeStats.totalCardsInHierarchy;
      cumulativeMastered += childCumulativeStats.masteredCards;
    });

    nodeStats.newCardsDue = cumulativeNew;
    nodeStats.learningCardsDue = cumulativeLearning;
    nodeStats.reviewCardsDue = cumulativeReview;
    nodeStats.totalCardsInHierarchy = cumulativeTotal;
    nodeStats.masteredCards = cumulativeMastered;
    nodeStats.progressPercent = cumulativeTotal > 0 ? Math.round((cumulativeMastered / cumulativeTotal) * 100) : 0;
    
    const cleanedStats: Partial<DeckStatsInternal> = { ...nodeStats };
    delete cleanedStats._directNew;
    delete cleanedStats._directLearning;
    delete cleanedStats._directReview;
    delete cleanedStats._directTotal;
    delete cleanedStats._directMastered;
    node.stats = cleanedStats as DeckStatsInternal;


    return { 
        newCardsDue: cumulativeNew, 
        learningCardsDue: cumulativeLearning, 
        reviewCardsDue: cumulativeReview, 
        totalCardsInHierarchy: cumulativeTotal,
        masteredCards: cumulativeMastered,
        progressPercent: nodeStats.progressPercent
    };
  };

  root.children.forEach(child => calculateCumulativeStats(child));
  
  const sortNodes = (node: DeckNodeDataInternal) => {
    node.children.sort((a, b) => a.name.localeCompare(b.name));
    node.children.forEach(sortNodes);
  };
  sortNodes(root);

  return root.children as DeckNodeData[];
};
