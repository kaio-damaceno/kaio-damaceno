
import { Flashcard } from '../types';

const FLASHCARDS_LOCAL_STORAGE_KEY = 'flashcards';

/**
 * Loads flashcards from localStorage.
 * @returns An array of Flashcard objects or an empty array if none found or error.
 */
export const loadFlashcards = (): Flashcard[] => {
  const savedCards = localStorage.getItem(FLASHCARDS_LOCAL_STORAGE_KEY);
  if (savedCards) {
    try {
      const parsed = JSON.parse(savedCards);
      // Basic validation: ensure it's an array and items look like flashcards
      if (Array.isArray(parsed) && (parsed.length === 0 || (parsed[0] && typeof parsed[0].id === 'string'))) {
        return parsed as Flashcard[];
      }
      console.warn("Invalid data found in localStorage for flashcards, returning empty array.");
      return [];
    } catch (e) {
      console.error("Error parsing flashcards from localStorage:", e);
      return [];
    }
  }
  return [];
};

/**
 * Saves flashcards to localStorage.
 * @param flashcards The array of Flashcard objects to save.
 */
export const saveFlashcards = (flashcards: Flashcard[]): void => {
  try {
    localStorage.setItem(FLASHCARDS_LOCAL_STORAGE_KEY, JSON.stringify(flashcards));
  } catch (e) {
    console.error("Error saving flashcards to localStorage:", e);
    // Potentially notify user or implement more robust error handling
  }
};

/**
 * Exports flashcards to a JSON file and triggers a download.
 * @param flashcards The array of Flashcard objects to export.
 * @throws Error if an issue occurs during file creation or download.
 */
export const exportFlashcardsToFile = (flashcards: Flashcard[]): void => {
  try {
    const jsonString = JSON.stringify(flashcards, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const date = new Date().toISOString().split('T')[0];
    a.download = `genkicards_backup_${date}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error("Export error:", err);
    throw new Error((err as Error).message || "Ocorreu um erro ao exportar o backup.");
  }
};

/**
 * Parses a JSON string from a backup file into an array of Flashcards.
 * @param jsonString The JSON string content of the backup file.
 * @returns An array of Flashcard objects, or null if parsing fails or data is invalid.
 */
export const parseFlashcardBackup = (jsonString: string): Flashcard[] | null => {
  try {
    const importedData = JSON.parse(jsonString);
    if (Array.isArray(importedData) && (importedData.length === 0 || (importedData[0] && typeof importedData[0].id === 'string'))) {
      // Further validation could be added here to check for specific Flashcard properties
      return importedData as Flashcard[];
    }
    console.warn("Invalid JSON backup file structure. Expected an array of flashcards.");
    return null;
  } catch (err) {
    console.error("Error parsing JSON backup file:", err);
    return null;
  }
};
