
import { GeneratedFlashcardPayload } from '../types';

const mapDifficulty = (ankiTerm?: string): 'fácil' | 'média' | 'difícil' => {
  const term = ankiTerm?.toLowerCase().trim();
  if (term === 'easy' || term === 'fácil' || term === '1') return 'fácil';
  if (term === 'hard' || term === 'difícil' || term === '3') return 'difícil';
  return 'média';
};

export const parseAnkiTxt = (txtContent: string): Promise<GeneratedFlashcardPayload[]> => {
  return new Promise((resolve, reject) => {
    try {
      const lines = txtContent.split(/\r?\n/);
      const flashcards: GeneratedFlashcardPayload[] = [];
      
      let separator = '\t'; // Default separator
      let hasHtml = false;
      let deckColumnIndex: number | null = null; // 0-indexed for array access
      let tagsColumnIndex: number | null = null; // 0-indexed for array access
      
      const dataLines: string[] = [];

      for (const line of lines) {
        if (line.startsWith('#')) {
          if (line.startsWith('#separator:')) {
            const sep = line.substring('#separator:'.length).trim().toLowerCase();
            if (sep === 'tab') separator = '\t';
            else if (sep === 'semicolon') separator = ';';
            else if (sep === 'comma') separator = ',';
            else if (sep.length === 1) separator = sep; // Allow any single char
            console.log("Using separator:", JSON.stringify(separator));
          } else if (line.startsWith('#html:')) {
            hasHtml = line.substring('#html:'.length).trim().toLowerCase() === 'true';
          } else if (line.startsWith('#deck column:')) {
            const col = parseInt(line.substring('#deck column:'.length).trim(), 10);
            if (!isNaN(col) && col > 0) deckColumnIndex = col - 1; // Convert to 0-indexed
          } else if (line.startsWith('#tags column:')) {
            const col = parseInt(line.substring('#tags column:'.length).trim(), 10);
            if (!isNaN(col) && col > 0) tagsColumnIndex = col - 1; // Convert to 0-indexed
          }
        } else if (line.trim() !== '') {
          dataLines.push(line);
        }
      }

      if (dataLines.length === 0) {
        resolve([]);
        return;
      }

      for (const line of dataLines) {
        const parts = line.split(separator);
        
        if (parts.length < 2 && !(hasHtml && parts.length >=1) ) { 
          console.warn(`Skipping malformed line (not enough parts with separator '${JSON.stringify(separator)}'): ${line}`);
          continue;
        }

        let pergunta = '';
        let resposta = '';
        let deckPath = 'Default';
        let tags: string[] = [];
        // Difficulty is not typically in Anki exports with these headers, default to 'média'
        const dificuldade: 'fácil' | 'média' | 'difícil' = 'média'; 

        let questionFieldIndex = 0;
        let answerFieldIndex = 1;

        if (deckColumnIndex !== null && deckColumnIndex < parts.length) {
          deckPath = parts[deckColumnIndex].trim() || 'Default';
          // If deck is in the first column (index 0), question and answer fields shift
          if (deckColumnIndex === 0) {
            questionFieldIndex = 1;
            answerFieldIndex = 2;
          }
        }
        
        if (questionFieldIndex < parts.length) {
            pergunta = parts[questionFieldIndex].trim();
        } else {
            console.warn(`Skipping line: Question field (index ${questionFieldIndex}) out of bounds for line: ${line}`);
            continue;
        }

        if (answerFieldIndex < parts.length) {
            resposta = parts[answerFieldIndex].trim();
        } else if (!hasHtml) { // If not HTML, answer is required
             console.warn(`Skipping line: Answer field (index ${answerFieldIndex}) out of bounds and not HTML for line: ${line}`);
             continue;
        } // If HTML, answer can be empty (e.g. cloze)

        if (tagsColumnIndex !== null && tagsColumnIndex < parts.length) {
          const rawTags = parts[tagsColumnIndex].trim();
          // Anki tags can be space or comma separated. Handle both robustly.
          if (rawTags) {
             tags = rawTags.split(/\s+|,/).map(tag => tag.trim()).filter(tag => tag);
          }
        }
        
        // Ensure pergunta has content, or if HTML, resposta might be main content for cloze
        if (pergunta || (hasHtml && resposta)) {
          flashcards.push({
            pergunta,
            resposta,
            dificuldade,
            tags,
            deckPath,
            htmlContent: hasHtml,
          });
        } else {
          console.warn(`Skipping line due to missing question or (answer when not HTML): ${line}`);
        }
      }
      resolve(flashcards);
    } catch (error) {
      console.error("Error parsing Anki TXT file:", error);
      reject(new Error("Failed to parse the Anki TXT file. Ensure it's a plain text file with Anki export format. Check console for details."));
    }
  });
};
