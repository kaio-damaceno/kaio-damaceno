
import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { GeneratedFlashcardPayload, GroundingMetadata, InputType } from '../types';
import { GEMINI_TEXT_MODEL, MOCK_API_KEY_WARNING } from '../constants';

const apiKey = process.env.API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
} else {
  console.warn(MOCK_API_KEY_WARNING);
}

const parseJsonFromText = <T,>(text: string): T | null => {
  let jsonStr = text.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; 
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", jsonStr, e);
    const jsonLooseRegex = /\[.*\]|\{.*\}/s;
    const looseMatch = jsonStr.match(jsonLooseRegex);
    if (looseMatch && looseMatch[0]) {
      try {
        return JSON.parse(looseMatch[0]) as T;
      } catch (e2) {
        console.error("Failed to parse JSON even with loose regex:", looseMatch[0], e2);
      }
    }
    throw new Error(`Invalid JSON response from AI: ${ (e as Error).message }`);
  }
};


export const generateFlashcardsFromText = async (
  inputText: string,
  inputType: InputType = InputType.TEXT
): Promise<GeneratedFlashcardPayload[]> => {
  if (!ai) throw new Error("API Key not configured. Cannot connect to AI service.");

  const context = inputType === InputType.VIDEO_TRANSCRIPT ? "video transcript" : inputType === InputType.TEXT && inputText.startsWith('http') ? "web article/page content" : "provided text";
  
  const prompt = `
    Analyze the following ${context}:
    \`\`\`
    ${inputText}
    \`\`\`
    Based ONLY on the provided content, generate 5-8 specific question-answer pairs suitable for flashcards.
    Focus on key concepts, definitions, important facts, or technical terms present in the text.
    Avoid overly broad, generic, or trivial questions (e.g., "What is science?").
    The questions should be answerable directly from the provided text.
    
    For each flashcard, also identify 2-4 relevant topical tags (keywords or short phrases) based on the content of that specific question-answer pair and the overall context. These tags should help categorize the card. Example tags: "Cellular Biology", "Photosynthesis", "World War II", "Economic Theories".

    If the text is too short or unsuitable for generating meaningful flashcards, return an empty array.

    Format the output as a JSON array of objects. Each object must have 'pergunta' (string), 'resposta' (string), 'dificuldade' (string: 'fácil', 'média', or 'difícil'), and 'tags' (array of strings).
    Example: [{"pergunta": "What is the main function of mitochondria?", "resposta": "To generate most of the cell's supply of adenosine triphosphate (ATP), used as a source of chemical energy.", "dificuldade": "média", "tags": ["cellular biology", "energy production", "ATP"]}]
    Ensure the JSON is valid.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        temperature: 0.5, 
      }
    });

    const rawJson = response.text;
    const parsedFlashcards = parseJsonFromText<GeneratedFlashcardPayload[]>(rawJson);
    
    if (!parsedFlashcards) {
         console.warn("AI returned non-JSON or unparsable response for text flashcards:", rawJson);
         throw new Error("AI response was not in the expected JSON format.");
    }
    if (!Array.isArray(parsedFlashcards)) {
        console.warn("AI returned a non-array JSON response for text flashcards:", parsedFlashcards);
        throw new Error("AI response was not a JSON array as expected.");
    }
    return parsedFlashcards.filter(card => card.pergunta && card.resposta && card.dificuldade);

  } catch (error) {
    console.error("Error generating flashcards from text:", error);
    throw new Error(`AI service error: ${ (error as Error).message }`);
  }
};


export const generateFlashcardsFromImage = async (
  base64Image: string,
  mimeType: string
): Promise<GeneratedFlashcardPayload[]> => {
  if (!ai) throw new Error("API Key not configured. Cannot connect to AI service.");

  const imagePart: Part = {
    inlineData: {
      mimeType: mimeType,
      data: base64Image,
    },
  };

  const textPart: Part = {
    text: `
      Extract all text from this image. Then, based ONLY on the extracted text, generate 3-6 specific question-answer pairs suitable for flashcards.
      Prioritize key information, definitions, technical terms, or important facts visible in the image text.
      Avoid generic questions. Questions must be answerable from the image's text content.

      For each flashcard, also identify 2-3 relevant topical tags (keywords or short phrases) based on the content of that specific question-answer pair and the overall context of the image text.
      
      If the image contains no discernible text or the text is insufficient for good flashcards, return an empty array.
      
      Format the output as a JSON array of objects. Each object must have 'pergunta' (string), 'resposta' (string), 'dificuldade' (string: 'fácil', 'média', or 'difícil'), and 'tags' (array of strings).
      Example: [{"pergunta": "What is the chemical symbol for water?", "resposta": "H2O", "dificuldade": "fácil", "tags": ["chemistry", "water", "chemical symbol"]}]
      Ensure the JSON is valid.
    `,
  };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL, 
      contents: [{ role: "user", parts: [imagePart, textPart] }],
      config: {
        responseMimeType: "application/json",
        temperature: 0.4,
      }
    });
    
    const rawJson = response.text;
    const parsedFlashcards = parseJsonFromText<GeneratedFlashcardPayload[]>(rawJson);

    if (!parsedFlashcards) {
        console.warn("AI returned non-JSON or unparsable response for image flashcards:", rawJson);
        throw new Error("AI response was not in the expected JSON format.");
    }
    if (!Array.isArray(parsedFlashcards)) {
        console.warn("AI returned a non-array JSON response for image flashcards:", parsedFlashcards);
        throw new Error("AI response was not a JSON array as expected.");
    }
    return parsedFlashcards.filter(card => card.pergunta && card.resposta && card.dificuldade);

  } catch (error) {
    console.error("Error generating flashcards from image:", error);
    throw new Error(`AI service error: ${ (error as Error).message }`);
  }
};

export const generateQuestionsFromText = async (explanation: string): Promise<string[]> => {
  if (!ai) throw new Error("API Key not configured. Cannot connect to AI service.");

  const prompt = `
    Based on the following explanation:
    \`\`\`
    ${explanation}
    \`\`\`
    Generate 3-5 distinct, objective questions that test comprehension of the material explained.
    The questions should require factual recall or understanding of concepts mentioned.
    Avoid yes/no questions if possible. Do not ask for opinions.
    If the explanation is too short or unclear for good questions, return an empty array.
    
    Format the output as a JSON array of strings.
    Example: ["What are the main components of X?", "Explain the process of Y.", "Who discovered Z?"]
    Ensure the JSON is valid.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        temperature: 0.6,
      }
    });

    const rawJson = response.text;
    const parsedQuestions = parseJsonFromText<string[]>(rawJson);
    
    if (!parsedQuestions) {
        console.warn("AI returned non-JSON or unparsable response for questions:", rawJson);
        throw new Error("AI response was not in the expected JSON format.");
    }
    if (!Array.isArray(parsedQuestions) || !parsedQuestions.every(q => typeof q === 'string')) {
        console.warn("AI returned a non-array or non-string-array JSON response for questions:", parsedQuestions);
        throw new Error("AI response was not a JSON array of strings as expected.");
    }
    return parsedQuestions;

  } catch (error) {
    console.error("Error generating questions from text:", error);
    throw new Error(`AI service error: ${ (error as Error).message }`);
  }
};

export const createFlashcardFromSpokenAnswer = async (
  question: string,
  spokenAnswer: string,
  contextExplanation?: string // This context is crucial for verification
): Promise<GeneratedFlashcardPayload> => {
  if (!ai) throw new Error("API Key not configured. Cannot connect to AI service.");

  let prompt = `
    A user was asked the following question:
    Question: "${question}"

    The user responded with:
    User's Answer: "${spokenAnswer}"
  `;

  if (contextExplanation) {
    prompt += `\n\nFor context, the original explanation provided by the user (from which the question was likely derived) was:
    Original Context: \`\`\`${contextExplanation}\`\`\`
    `;
  } else {
     prompt += `\n\nNo original context explanation was provided. Evaluate the answer based on general knowledge if the question is general, or state if it's too specific to verify without context.`;
  }

  prompt += `
    Your Task: Create a single, high-quality flashcard.
    1.  Critically evaluate the User's Answer for accuracy, completeness, and clarity in relation to the Question and the Original Context (if available).
    2.  The 'pergunta' field of the flashcard MUST be the original Question: "${question}".
    3.  For the 'resposta' field:
        *   If the User's Answer is accurate, clear, and concise, use it directly or with minor corrections for grammar/flow.
        *   If the User's Answer is incorrect, significantly incomplete, or very poorly phrased, you MUST generate a correct, concise, and well-phrased 'resposta' based PRIMARILY on the Original Context. If the Original Context is insufficient, use general knowledge for common topics or state that a definitive answer cannot be formed from the provided information. You can optionally preface a corrected answer with "(System Corrected) ".
        *   If the User's Answer is partially correct, refine it to be fully accurate and clear, using the Original Context.
    4.  Determine the 'dificuldade' ('fácil', 'média', 'difícil') based on the inherent complexity of the question's topic and the presumed effort to recall the correct answer. Default to 'média' if unsure.
    5.  Also, suggest 1-2 'tags' (array of strings) for this flashcard based on the question and answer content. Example tags: "Physics", "Newtonian Mechanics".

    Format the output as a single JSON object with 'pergunta' (string), 'resposta' (string), 'dificuldade' (string: 'fácil', 'média', or 'difícil'), and 'tags' (array of strings).
    Example: {"pergunta": "What is photosynthesis?", "resposta": "The process by which green plants use sunlight, water, and carbon dioxide to create their own food and release oxygen.", "dificuldade": "média", "tags": ["biology", "plants"]}
    Ensure the JSON is valid.
  `;
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        temperature: 0.4, 
      }
    });
    
    const rawJson = response.text;
    const parsedCard = parseJsonFromText<GeneratedFlashcardPayload>(rawJson);

    if (!parsedCard || typeof parsedCard !== 'object' || !parsedCard.pergunta || !parsedCard.resposta || !parsedCard.dificuldade) {
      console.warn("AI returned invalid JSON object for spoken answer flashcard:", parsedCard);
      // Fallback if AI fails to produce valid JSON, using the original spoken answer with a note.
      return {
        pergunta: question,
        resposta: spokenAnswer + (contextExplanation ? " (Self-answered, verify)" : " (Self-answered)"),
        dificuldade: 'média',
        tags: []
      };
    }
    return parsedCard;

  } catch (error) {
    console.error("Error creating flashcard from spoken answer:", error);
    // Fallback on error
     return {
        pergunta: question,
        resposta: spokenAnswer + " (Error processing answer, please verify)",
        dificuldade: 'média',
        tags: []
      };
  }
};

export const getGroundedAnswer = async (query: string): Promise<{ text: string, metadata?: GroundingMetadata }> => {
  if (!ai) throw new Error("API Key not configured. Cannot connect to AI service.");
  try {
    const response = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: "user", parts: [{ text: query }] }],
      config: {
        tools: [{ googleSearch: {} }], 
      },
    });
    
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata as GroundingMetadata | undefined;
    return { text: response.text, metadata: groundingMetadata };

  } catch (error) {
    console.error("Error getting grounded answer:", error);
    throw new Error(`AI service error: ${ (error as Error).message }`);
  }
};
